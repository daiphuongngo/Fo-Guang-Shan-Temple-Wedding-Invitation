# ServiceBusQueuesDemo — ASP.NET Core Web API

An ASP.NET Core 10 Web API that acts as the **message producer** in the Service Bus Queues demo. It exposes a single REST endpoint that sends a text message to the `thingstodo` Azure Service Bus queue.

---

## Architecture

```mermaid
graph TD
    Client([Browser / HTTP Client])
    Swagger[Swagger UI\nhttps://localhost:9117]
    Controller[ThingsToDoController\nPOST /api/v1/thingstodo]
    Config[IConfiguration\nConnectionStrings:\nServiceBusConnectionString]
    Client2[ServiceBusClient]
    Sender[ServiceBusSender\nqueue: thingstodo]
    Queue[(Azure Service Bus\nthingstodo Queue)]

    Client -- "Opens" --> Swagger
    Swagger -- "POST body: message string" --> Controller
    Controller -- "reads connection string" --> Config
    Controller -- "new ServiceBusClient\n(connectionString)" --> Client2
    Client2 -- "CreateSender\n(thingstodo)" --> Sender
    Sender -- "SendMessageAsync\n(ServiceBusMessage)" --> Queue

    style Controller fill:#0078D4,color:#fff
    style Queue fill:#F25022,color:#fff
    style Swagger fill:#85C1E9,color:#000
```

---

## Project Structure

```mermaid
graph LR
    Project[ServiceBusQueuesDemo.csproj\nnet10.0 Web SDK]
    Program[Program.cs\nStartup & Swagger\nconfiguration]
    Controller[Controllers/\nThingsToDoController.cs]
    Settings[appsettings.json\nConnectionStrings placeholder]
    Launch[Properties/\nlaunchSettings.json\nPort 9117 / 9281]

    Project --> Program
    Project --> Controller
    Project --> Settings
    Project --> Launch
```

---

## API Endpoint

### POST `/api/v1/thingstodo`

Sends a message to the `thingstodo` Service Bus queue.

| Property | Value |
|---|---|
| Method | `POST` |
| Route | `/api/v1/thingstodo` |
| Content-Type | `application/json` |
| Request Body | JSON string, e.g. `"Hello World"` |
| Success Response | `202 Accepted` |
| Error Response | `400 Bad Request` |

#### Example Request
```http
POST https://localhost:9117/api/v1/thingstodo
Content-Type: application/json

"Hello from Harvard 2026!"
```

#### Example Response
```
HTTP/1.1 202 Accepted
```

---

## Message Flow

Each call to the endpoint:
1. Creates a new `ServiceBusClient` using the configured connection string.
2. Creates a `ServiceBusSender` targeting the `thingstodo` queue.
3. Wraps the body string in a `ServiceBusMessage` with a new `Guid` as the `MessageId`.
4. Sends the message asynchronously.

---

## Configuration

The connection string is read from `IConfiguration` under `ConnectionStrings:ServiceBusConnectionString`.

**User Secrets (recommended for local development):**
```bash
dotnet user-secrets set "ConnectionStrings:ServiceBusConnectionString" "<your-connection-string>"
```

**Or edit `appsettings.json` directly** (do not commit secrets):
```json
{
  "ConnectionStrings": {
    "ServiceBusConnectionString": "<your connection string goes here>"
  }
}
```

---

## Running the API

```bash
cd ServiceBusQueuesDemo
dotnet run
```

The Swagger UI launches at `https://localhost:9117` (or `http://localhost:9281`).

---

## Dependencies

| Package | Version | Purpose |
|---|---|---|
| `Azure.Messaging.ServiceBus` | 7.20.1 | Azure Service Bus SDK |
| `Swashbuckle.AspNetCore` | 6.9.0 | Swagger / OpenAPI documentation UI |
