﻿// CSCI-E94 Fundamendals of cloud computing Service Bus Queues Demo
// Joseph Ficara (c) 2018-2022

using Azure.Messaging.ServiceBus;
using Microsoft.AspNetCore.Mvc;

namespace ServiecBusQueuesDemo.Controllers
{
    /// <summary>
    /// Creates messages in the thingstodo queue
    /// </summary>
    /// <seealso cref="ControllerBase" />
    [Produces("application/json")]
    [Route("api/v1/[controller]")]
    [ApiController]
    public class ThingsToDoController : ControllerBase
    {
        /// <summary>
        /// The configuration instance
        /// </summary>
        private readonly IConfiguration _configuration;

        /// <summary>
        /// The azure service bus queue name
        /// </summary>
        private readonly string _queueName = "thingstodo";


        /// <summary>
        /// Gets the service bus connection string.
        /// </summary>
        /// <value>The service bus connection string.</value>
        private string ServiceBusConnectionString
        {
            get
            {
                return _configuration.GetConnectionString("ServiceBusConnectionString");
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ThingsToDoController"/> class.
        /// </summary>
        public ThingsToDoController(IConfiguration configuration)
        {
            _configuration = configuration;
        }


        /// <summary>
        /// Creates a text message with a username property set to the userName
        /// and a message body set to the message
        /// </summary>
        /// <param name="message">The message content.</param>
        /// <returns>Task&lt;IActionResult&gt;.</returns>
        [ProducesResponseType(typeof(string), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Route("/api/v1/thingstodo")]
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] string message)
        {
            // 1. Create the Service Bus Client
            ServiceBusClient serviceBusClient = new ServiceBusClient(ServiceBusConnectionString);

            // 2. Create the sender to include the message to send
            ServiceBusSender sender = serviceBusClient.CreateSender(_queueName);
            ServiceBusMessage serviceBusMessage = new ServiceBusMessage(message);
            serviceBusMessage.MessageId = Guid.NewGuid().ToString();

            // 3. Send the message
            await sender.SendMessageAsync(serviceBusMessage);

            // Not providing a URL because we are not providing retrieval support
            return Accepted();
        }
    }
}
