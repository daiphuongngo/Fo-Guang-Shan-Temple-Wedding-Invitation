﻿// See https://aka.ms/new-console-template for more information

using Microsoft.Extensions.Configuration;
using Azure.Messaging.ServiceBus;
using System.Text;

IConfiguration _configuration = SetupConfigurationSupport();

// This runs the application
await ReceiveMessages();


/// <summary>
/// Set up the configuration support.
/// </summary>
IConfiguration SetupConfigurationSupport()
{
    var builder = new ConfigurationBuilder()
             .SetBasePath(Directory.GetCurrentDirectory())
             .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
             .AddUserSecrets("b5c0770a-1f5b-48f9-8bfc-833f3dc41ed6");

    return _configuration = builder.Build();
}


/// <summary>
/// Set up the service bus client and receive messages
/// </summary>
async Task ReceiveMessages()
{
    /// <summary>
    /// The azure service bus topic name
    /// </summary>
    const string queueName = "thingstodo";
    ServiceBusClient _serviceBusClient = new ServiceBusClient(_configuration.GetConnectionString("ServiceBusConnectionString"));

    // 1. Create the service bus receiver
    ServiceBusReceiver serviceBusReceiver = _serviceBusClient.CreateReceiver(queueName: queueName);

    // 2. Configure the message handler options in terms of exception handling, 
    // number of concurrent messages to deliver, etc.
    ServiceBusProcessorOptions serviceBusProcessorOptions = new ServiceBusProcessorOptions
    {
        // Maximum number of concurrent calls to the callback ProcessMessagesAsync(), 
        // set to 1 for simplicity.
        // Set it according to how many message to process in parallel
        MaxConcurrentCalls = 1,

        // Indicates whether the message pump should automatically complete the messages after returning from user callback.
        // False below indicates the complete operation is handled by the user callback as in ProcessMessagesAsync().
        AutoCompleteMessages = false
    };

    // 3. Create a processor that we can use to process the messages
    await using ServiceBusProcessor processor = _serviceBusClient.CreateProcessor(queueName: queueName,options: serviceBusProcessorOptions);

    // 4. Register the functions that processes messages.
    processor.ProcessMessageAsync += ProcessMessagesAsync;
    processor.ProcessErrorAsync += ErrorMessageHandler;

    // 7. Start processing messages
    await processor.StartProcessingAsync();
    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine("Demo azure service bus queues");
    Console.ReadKey();
}

/// <summary>
/// 5. Message Handler Method
/// </summary>
/// <param name="message">The message.</param>
/// <param name="token">The token.</param>
/// <returns>Task.</returns>
async Task ProcessMessagesAsync(ProcessMessageEventArgs arg)
{
    // Process the message.
    string messageText = Encoding.UTF8.GetString(arg.Message.Body);
    Console.Write(value: $"{DateTime.Now:HH:mm:ss.fffff}: Received message: Sequence Number:[{arg.Message.SequenceNumber}] Body:");
    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.WriteLine($"[{messageText}]");
    Console.ForegroundColor = ConsoleColor.Green;

    // Demo automatic move to dead letter queue
    if (messageText.Equals("exception", StringComparison.InvariantCultureIgnoreCase))
    {
        throw new SystemException("Failed processing message");
    }

    // Demo manual move to dead letter queue
    if (messageText.Equals("fail", StringComparison.InvariantCultureIgnoreCase))
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Moved to dead letter queue");
        await arg.DeadLetterMessageAsync(arg.Message, deadLetterReason: "Test Failure", deadLetterErrorDescription: "Received 'fail' message");
        Console.ForegroundColor = ConsoleColor.Green;
        return;
    }

    // Complete the message so that it is not received again.
    // This can be done only if the queue Client is created in ReceiveMode.PeekLock mode (which is the default).
    if (!arg.CancellationToken.IsCancellationRequested)
    {
        await arg.CompleteMessageAsync(arg.Message);
    }

    // Note: Use the cancellationToken passed as necessary to determine if the request has been cancled
    // If request has already been closed, you can choose to not call CompleteAsync() or AbandonAsync() etc.
    // to avoid unnecessary exceptions.
}

/// <summary>
/// 6. Exception handler method
/// </summary>
/// <param name="exceptionReceivedEventArgs">The <see cref="ExceptionReceivedEventArgs"/> instance containing the event data.</param>
/// <returns>Task.</returns>
/// <remarks>Use this handler to examine the exceptions received on the message pump.</remarks>
Task ErrorMessageHandler(ProcessErrorEventArgs arg)
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine($"Message handler encountered an exception {arg.Exception.Message}.");

    Console.WriteLine("Exception context for troubleshooting:");
    Console.WriteLine($"- Namespace: {arg.FullyQualifiedNamespace}");
    Console.ForegroundColor = ConsoleColor.Green;
    return Task.CompletedTask;
}

