# QueueReceiverDemo — .NET Console App

A .NET 10 console application that acts as the **message consumer** in the Service Bus Queues demo. It uses a `ServiceBusProcessor` to continuously listen on the `thingstodo` queue and process incoming messages — including demonstrating automatic and manual dead-letter queue routing.

---

## Architecture

```mermaid
graph TD
    Queue[(Azure Service Bus\nthingstodo Queue)]
    DLQ[(Dead-Letter\nQueue)]
    Config[IConfiguration\nConnectionStrings:\nServiceBusConnectionString\nappsettings.json + User Secrets]
    Client[ServiceBusClient]
    Processor[ServiceBusProcessor\nMaxConcurrentCalls: 1\nAutoCompleteMessages: false]
    MsgHandler[ProcessMessagesAsync\nMessage Handler]
    ErrHandler[ErrorMessageHandler\nError Handler]
    Console([Console Output\nColored + Timestamped])

    Config --> Client
    Client -- "CreateProcessor\n(thingstodo)" --> Processor
    Processor -- "ProcessMessageAsync event" --> MsgHandler
    Processor -- "ProcessErrorAsync event" --> ErrHandler
    Queue -- "receive" --> Processor
    MsgHandler -- "CompleteMessageAsync" --> Queue
    MsgHandler -- "DeadLetterMessageAsync\nor throws exception" --> DLQ
    MsgHandler --> Console
    ErrHandler --> Console

    style Processor fill:#107C10,color:#fff
    style Queue fill:#F25022,color:#fff
    style DLQ fill:#7F7F7F,color:#fff
    style Console fill:#1C1C1C,color:#0f0
```

---

## Message Processing Flow

```mermaid
flowchart TD
    Start([Receive Message from Queue]) --> ReadBody[Read message body as UTF-8 string]
    ReadBody --> Print[Print to console with timestamp]
    Print --> Check1{body == 'exception'\ncase insensitive?}
    Check1 -- Yes --> Throw[Throw SystemException\nAuto dead-letter after max\ndelivery count exceeded]
    Check1 -- No --> Check2{body == 'fail'\ncase insensitive?}
    Check2 -- Yes --> DL[DeadLetterMessageAsync\nreason: Test Failure\nmanual dead-letter]
    Check2 -- No --> Check3{CancellationToken\nrequested?}
    Check3 -- No --> Complete[CompleteMessageAsync\nremove from queue]
    Check3 -- Yes --> Skip[Skip — do nothing\navoid exception on\nclosed connection]

    style Throw fill:#F25022,color:#fff
    style DL fill:#7F7F7F,color:#fff
    style Complete fill:#107C10,color:#fff
```

---

## Project Structure

```mermaid
graph LR
    Project[QueueReceiverDemo.csproj\nnet10.0 Console SDK]
    Program[Program.cs\nTop-level statements\nSetupConfigurationSupport\nReceiveMessages\nProcessMessagesAsync\nErrorMessageHandler]
    Settings[appsettings.json\nConnectionStrings placeholder\nCopied to output dir]

    Project --> Program
    Project --> Settings
```

---

## Dead-Letter Queue Demo

The receiver demonstrates two ways a message ends up in the Dead-Letter Queue (DLQ):

| Trigger | Method | Description |
|---|---|---|
| Send `"exception"` | Unhandled `SystemException` thrown | Azure automatically moves to DLQ after max delivery count |
| Send `"fail"` | `DeadLetterMessageAsync` called explicitly | Manual dead-letter with custom reason and description |

> **Tip:** View dead-lettered messages in the Azure Portal under your queue's **Dead-letter** sub-queue, or using tools like Service Bus Explorer.

---

## Configuration

The connection string is read from `IConfiguration` using both `appsettings.json` and User Secrets.

**User Secrets (recommended for local development):**
```bash
dotnet user-secrets set "ConnectionStrings:ServiceBusConnectionString" "<your-connection-string>"
```

**Or edit `appsettings.json` directly** (do not commit secrets):
```json
{
  "ConnectionStrings": {
    "ServiceBusConnectionString": "<your connection string goes here>"
  }
}
```

---

## Running the Console App

```bash
cd QueueReceiverDemo
dotnet run
```

The console displays in green:
```
Demo azure service bus queues
```

Press any key to stop the processor.

**Console output colors:**
- 🟢 Green — startup message and normal status
- 🔵 Cyan — received message body
- 🟡 Yellow — message moved to dead-letter queue (`"fail"`)
- 🔴 Red — error handler output

---

## Dependencies

| Package | Version | Purpose |
|---|---|---|
| `Azure.Messaging.ServiceBus` | 7.20.1 | Azure Service Bus SDK |
| `Microsoft.Extensions.Configuration` | 10.0.7 | Configuration infrastructure |
| `Microsoft.Extensions.Configuration.Abstractions` | 10.0.7 | Configuration abstractions |
| `Microsoft.Extensions.Configuration.UserSecrets` | 10.0.7 | User secrets support for local dev |
