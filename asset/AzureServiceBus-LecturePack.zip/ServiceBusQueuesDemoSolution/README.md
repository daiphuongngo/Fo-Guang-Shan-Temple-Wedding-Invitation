# Azure Service Bus Queues Demo Solution

A .NET 10 demonstration of Azure Service Bus queue messaging using a two-project architecture: an ASP.NET Core Web API that sends messages and a console application that receives and processes them in real time.

---

## Overall Architecture

```mermaid
graph TD
    User([Developer / Browser])
    API[ServiceBusQueuesDemo\nASP.NET Core Web API\nPort 9117 / 9281]
    SBN[Azure Service Bus\nNamespace]
    Q[(thingstodo\nQueue)]
    Console[QueueReceiverDemo\n.NET Console App]
    DLQ[(Dead-Letter\nQueue)]

    User -- "POST /api/v1/thingstodo\n{ message }" --> API
    API -- "SendMessageAsync" --> SBN
    SBN --> Q
    Console -- "ServiceBusProcessor\n(receive loop)" --> Q
    Q -- "Completes message" --> Console
    Console -- "DeadLetterMessageAsync\nor unhandled exception" --> DLQ

    style API fill:#0078D4,color:#fff
    style Console fill:#107C10,color:#fff
    style SBN fill:#F25022,color:#fff
    style Q fill:#F25022,color:#fff
    style DLQ fill:#7F7F7F,color:#fff
```

---

## Projects

| Project | Type | Role |
|---|---|---|
| [ServiceBusQueuesDemo](ServiceBusQueuesDemo/README.md) | ASP.NET Core Web API | Sends messages to the Service Bus queue via a REST endpoint |
| [QueueReceiverDemo](QueueReceiverDemo/README.md) | .NET Console App | Continuously receives and processes messages from the queue |

---

## Azure Dependencies

### Required Azure Resources

| Resource | Description |
|---|---|
| **Azure Service Bus Namespace** | Standard or Premium tier namespace to host the queue |
| **Service Bus Queue: `thingstodo`** | The queue used for message exchange between the two apps |

### Creating the Azure Service Bus Queue

#### Option 1 — Azure Portal
1. Navigate to your **Service Bus Namespace** in the Azure Portal.
2. Select **Queues** from the left menu.
3. Click **+ Queue**.
4. Set the **Name** to `thingstodo`.
5. Leave default settings (or adjust lock duration / max size as needed).
6. Click **Create**.

#### Option 2 — Azure CLI
```bash
# Create a resource group (if needed)
az group create --name rg-servicebus-demo --location eastus

# Create a Service Bus Namespace (Standard tier required for queues)
az servicebus namespace create \
  --name <your-namespace-name> \
  --resource-group rg-servicebus-demo \
  --sku Standard \
  --location eastus

# Create the thingstodo queue
az servicebus queue create \
  --name thingstodo \
  --namespace-name <your-namespace-name> \
  --resource-group rg-servicebus-demo
```

### Obtaining the Connection String
1. In the Azure Portal, navigate to your **Service Bus Namespace**.
2. Select **Shared access policies** → **RootManageSharedAccessKey**.
3. Copy the **Primary Connection String**.

---

## Configuration

Both projects read the Service Bus connection string from **User Secrets** (recommended for local development) or `appsettings.json`.

### ServiceBusQueuesDemo (API)
```bash
cd ServiceBusQueuesDemo
dotnet user-secrets set "ConnectionStrings:ServiceBusConnectionString" "<your-connection-string>"
```

### QueueReceiverDemo (Console)
```bash
cd QueueReceiverDemo
dotnet user-secrets set "ConnectionStrings:ServiceBusConnectionString" "<your-connection-string>"
```

Alternatively, edit each project's `appsettings.json` and replace the placeholder value:
```json
{
  "ConnectionStrings": {
    "ServiceBusConnectionString": "<your connection string goes here>"
  }
}
```

---

## Running the Demo

> **Both applications must be running at the same time.** The API sends messages and the console app receives them.

### Step 1 — Start the Console Receiver
Open a terminal in the solution root and run:
```bash
cd QueueReceiverDemo
dotnet run
```
You will see:
```
Demo azure service bus queues
```
The console is now listening on the `thingstodo` queue. Press any key to stop.

### Step 2 — Start the API
Open a **second terminal** and run:
```bash
cd ServiceBusQueuesDemo
dotnet run
```
The Swagger UI opens automatically in your browser at `https://localhost:9117`.

### Step 3 — Send Messages
1. In the Swagger UI, expand **POST** `/api/v1/thingstodo`.
2. Click **Try it out**.
3. Enter a message string in the request body, e.g. `"Hello from Harvard 2026!"`.
4. Click **Execute**.
5. Observe the message appear in the **console receiver** window with a timestamp.

### Special Messages
The console receiver demonstrates dead-letter queue handling:

| Message | Behavior |
|---|---|
| `"exception"` | Throws an unhandled exception → message auto-moved to Dead-Letter Queue |
| `"fail"` | Explicitly calls `DeadLetterMessageAsync` → message moved to Dead-Letter Queue with reason |
| Any other text | Message is received, printed, and completed (removed from queue) |

---

## Solution Structure

```
ServiceBusQueuesDemoSolution/
├── ServiceBusQueuesDemoSolution.sln
├── README.md                          ← You are here
├── ServiceBusQueuesDemo/              ← ASP.NET Core Web API
│   ├── Controllers/
│   │   └── ThingsToDoController.cs
│   ├── Properties/
│   │   └── launchSettings.json
│   ├── appsettings.json
│   ├── Program.cs
│   ├── README.md
│   └── ServiceBusQueuesDemo.csproj
└── QueueReceiverDemo/                 ← .NET Console App
    ├── appsettings.json
    ├── Program.cs
    ├── README.md
    └── QueueReceiverDemo.csproj
```

---

## Technology Stack

| Component | Technology |
|---|---|
| Runtime | .NET 10 |
| API Framework | ASP.NET Core 10 |
| API Documentation | Swashbuckle / Swagger UI |
| Messaging SDK | Azure.Messaging.ServiceBus 7.20.1 |
| Configuration | Microsoft.Extensions.Configuration 10.0.7 |
