# SetupTopicsAndQueues.ps1
# CSCI-E94 Fundamentals of Cloud Computing
# Creates the Azure Service Bus namespace (if needed), queue, topic, and subscriptions
# required by the ServiceBusQueuesDemoSolution, ServiceBusTopicsDemoSolution, and
# AzureFunctionsServiceBusDemoSolution projects.
#
# Subscription routing for testmessagetopic:
#   animals  - SQL filter: speciesType = 'animals'
#   humans   - SQL filter: speciesType = 'humans'
#   auditlog - TrueFilter (receives all messages regardless of speciesType)
#
# This script is idempotent: each resource is skipped if it already exists.
# Subscription selection is scoped to the tenant of the currently logged-in user;
# subscriptions from other tenants in the local CLI cache are excluded.
#
# Namespace creation: if no Service Bus namespace exists in the selected resource group,
# this script will create one (Standard tier) using a name you provide.
#
# Secrets verification: the primary connection string is always verified against every
# project's user-secrets store and the Azure Functions local.settings.json.  If a secret
# is missing or does not match the current namespace, it is updated automatically via
# 'dotnet user-secrets' (which also adds <UserSecretsId> to the .csproj if not already
# present).  local.settings.json is created if it does not exist.
#
# Prerequisites: Azure CLI (az) and .NET SDK (dotnet) installed.
#               Login is handled automatically.

$QueueName = "thingstodo"
$TopicName = "testmessagetopic"

# ---------------------------------------------------------------------------
# Helper: Display a numbered list and return the item the user selects
# ---------------------------------------------------------------------------
function Select-FromList {
    param(
        [string]   $Prompt,
        [string[]] $Items
    )

    if ($Items.Count -eq 0) {
        Write-Error "No items available to select from."
        exit 1
    }

    Write-Host ""
    Write-Host $Prompt -ForegroundColor Cyan
    for ($i = 0; $i -lt $Items.Count; $i++) {
        Write-Host ("  [{0,2}] {1}" -f ($i + 1), $Items[$i])
    }
    Write-Host ""

    while ($true) {
        $input = Read-Host "  Enter number (1-$($Items.Count))"
        if ($input -match '^\d+$') {
            $index = [int]$input - 1
            if ($index -ge 0 -and $index -lt $Items.Count) {
                return $Items[$index]
            }
        }
        Write-Host "  Invalid selection. Please enter a number between 1 and $($Items.Count)." -ForegroundColor Yellow
    }
}

# ---------------------------------------------------------------------------
# Step 1: Ensure the user is logged in — auto-login if not, then show context
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "=== Service Bus Infrastructure Setup ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "Checking Azure login status..." -ForegroundColor Yellow

az account show --output none 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Not logged in. Starting Azure login..." -ForegroundColor Yellow
    az login
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Azure login failed. Please run 'az login' manually and try again."
        exit 1
    }
    Write-Host "Login successful." -ForegroundColor Green
} else {
    Write-Host "Already logged in." -ForegroundColor Green
}

# Resolve the active user and tenant so we can scope subscription discovery
# and display context to the user before prompting.
$currentUser   = az account show --query "user.name" -o tsv 2>$null
$currentTenant = az account show --query "tenantId" -o tsv 2>$null
$tenantName    = az account show --query "tenantDisplayName" -o tsv 2>$null
if (-not $tenantName) { $tenantName = $currentTenant }

Write-Host ""
Write-Host "  User   : $currentUser" -ForegroundColor Green
Write-Host "  Tenant : $tenantName ($currentTenant)" -ForegroundColor Green

# ---------------------------------------------------------------------------
# Step 2: Select subscription (scoped to the current tenant only)
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "Fetching subscriptions for tenant '$tenantName'..." -ForegroundColor Yellow
$subscriptions   = az account list --refresh --query "[?tenantId=='$currentTenant'].{display:join(' | ', [name, id])}" -o tsv 2>$null
$subscriptionIds = az account list --query "[?tenantId=='$currentTenant'].id" -o tsv 2>$null

$subDisplayList = @($subscriptions)
$subIdList      = @($subscriptionIds)

if ($subDisplayList.Count -eq 1) {
    $selectedSubDisplay = $subDisplayList[0]
    $SubscriptionId     = $subIdList[0]
    Write-Host "  Only one subscription found — auto-selected: $selectedSubDisplay" -ForegroundColor Green
} else {
    $selectedSubDisplay = Select-FromList -Prompt "Select an Azure Subscription:" -Items $subDisplayList

    # Resolve the matching subscription ID from the selected display string
    $selectedIndex  = [Array]::IndexOf($subDisplayList, $selectedSubDisplay)
    $SubscriptionId = $subIdList[$selectedIndex]

    Write-Host "  Selected: $selectedSubDisplay" -ForegroundColor Green
}

# ---------------------------------------------------------------------------
# Step 3: Select resource group
# ---------------------------------------------------------------------------
$resourceGroups = az group list `
    --subscription $SubscriptionId `
    --query "[].name" -o tsv 2>$null

$ResourceGroup = Select-FromList `
    -Prompt "Select a Resource Group (subscription: $SubscriptionId):" `
    -Items @($resourceGroups)

Write-Host "  Selected: $ResourceGroup" -ForegroundColor Green

# ---------------------------------------------------------------------------
# Step 4: Verify Service Bus namespace — select existing or create new
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "--- Service Bus Namespace ---" -ForegroundColor Cyan
Write-Host "  Checking for Service Bus namespaces in resource group '$ResourceGroup'..." -ForegroundColor Yellow

$namespaces = az servicebus namespace list `
    --resource-group $ResourceGroup `
    --subscription $SubscriptionId `
    --query "[].name" -o tsv 2>$null

if (-not $namespaces) {
    Write-Host "  No Service Bus namespaces found in resource group '$ResourceGroup'." -ForegroundColor Yellow
    Write-Host ""

    $Namespace = Read-Host "  Enter a name for the new Service Bus namespace"
    if ([string]::IsNullOrWhiteSpace($Namespace)) {
        Write-Error "Namespace name cannot be empty."
        exit 1
    }

    Write-Host "  Creating Service Bus namespace '$Namespace' (Standard tier)..." -ForegroundColor Yellow
    az servicebus namespace create `
        --name $Namespace `
        --resource-group $ResourceGroup `
        --subscription $SubscriptionId `
        --sku Standard | Out-Null

    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to create Service Bus namespace '$Namespace'. Check that the name is globally unique and try again."
        exit 1
    }

    Write-Host "  Namespace '$Namespace' created successfully." -ForegroundColor Green
} else {
    $nsList = @($namespaces)
    if ($nsList.Count -eq 1) {
        $Namespace = $nsList[0]
        Write-Host "  Only one namespace found — auto-selected: $Namespace" -ForegroundColor Green
    } else {
        Write-Host "  Namespace(s) found." -ForegroundColor Green
        $Namespace = Select-FromList `
            -Prompt "Select a Service Bus Namespace (resource group: $ResourceGroup):" `
            -Items $nsList
        Write-Host "  Selected: $Namespace" -ForegroundColor Green
    }
}

# ---------------------------------------------------------------------------
# Summary before proceeding
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "--- Configuration ---" -ForegroundColor Cyan
Write-Host "  Subscription  : $SubscriptionId"
Write-Host "  Resource Group: $ResourceGroup"
Write-Host "  Namespace     : $Namespace"
Write-Host "  Queue         : $QueueName"
Write-Host "  Topic         : $TopicName"
Write-Host ""

az account set --subscription $SubscriptionId

# ---------------------------------------------------------------------------
# Queue: thingstodo
# Used by: ServiceBusQueuesDemo / ThingsToDoController
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "--- Queue: $QueueName ---" -ForegroundColor Cyan

Write-Host "  Checking if queue '$QueueName' exists..." -ForegroundColor Yellow
$existingQueue = az servicebus queue show `
    --name $QueueName `
    --namespace-name $Namespace `
    --resource-group $ResourceGroup `
    --query "name" -o tsv 2>$null

if ($existingQueue) {
    Write-Host "  Queue '$QueueName' already exists, skipping." -ForegroundColor Green
} else {
    Write-Host "  Queue '$QueueName' not found." -ForegroundColor Yellow
    Write-Host "  Creating queue '$QueueName'..." -ForegroundColor Yellow
    az servicebus queue create `
        --name $QueueName `
        --namespace-name $Namespace `
        --resource-group $ResourceGroup | Out-Null
    Write-Host "  Queue '$QueueName' created successfully." -ForegroundColor Green
}

# ---------------------------------------------------------------------------
# Topic: testmessagetopic
# Used by: ServiceBusTopicsDemo / TextMessagesController
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "--- Topic: $TopicName ---" -ForegroundColor Cyan

Write-Host "  Checking if topic '$TopicName' exists..." -ForegroundColor Yellow
$existingTopic = az servicebus topic show `
    --name $TopicName `
    --namespace-name $Namespace `
    --resource-group $ResourceGroup `
    --query "name" -o tsv 2>$null

if ($existingTopic) {
    Write-Host "  Topic '$TopicName' already exists, skipping." -ForegroundColor Green
} else {
    Write-Host "  Topic '$TopicName' not found." -ForegroundColor Yellow
    Write-Host "  Creating topic '$TopicName'..." -ForegroundColor Yellow
    az servicebus topic create `
        --name $TopicName `
        --namespace-name $Namespace `
        --resource-group $ResourceGroup | Out-Null
    Write-Host "  Topic '$TopicName' created successfully." -ForegroundColor Green
}

# ---------------------------------------------------------------------------
# Subscription: animals
# SQL filter: speciesType = 'animals'
# Used by: AnimalSubscription project
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "--- Subscription: animals ---" -ForegroundColor Cyan

Write-Host "  Checking if subscription 'animals' exists..." -ForegroundColor Yellow
$existingAnimals = az servicebus topic subscription show `
    --name "animals" `
    --topic-name $TopicName `
    --namespace-name $Namespace `
    --resource-group $ResourceGroup `
    --query "name" -o tsv 2>$null

if ($existingAnimals) {
    Write-Host "  Subscription 'animals' already exists, skipping." -ForegroundColor Green
} else {
    Write-Host "  Subscription 'animals' not found." -ForegroundColor Yellow
    Write-Host "  Creating subscription 'animals'..." -ForegroundColor Yellow
    az servicebus topic subscription create `
        --name "animals" `
        --topic-name $TopicName `
        --namespace-name $Namespace `
        --resource-group $ResourceGroup | Out-Null

    Write-Host "  Removing default filter rule '`$Default'..." -ForegroundColor Yellow
    az servicebus topic subscription rule delete `
        --name '$Default' `
        --subscription-name "animals" `
        --topic-name $TopicName `
        --namespace-name $Namespace `
        --resource-group $ResourceGroup | Out-Null

    Write-Host "  Adding SQL filter rule 'AnimalsFilter' (speciesType = 'animals')..." -ForegroundColor Yellow
    az servicebus topic subscription rule create `
        --name "AnimalsFilter" `
        --subscription-name "animals" `
        --topic-name $TopicName `
        --namespace-name $Namespace `
        --resource-group $ResourceGroup `
        --filter-sql-expression "speciesType = 'animals'" | Out-Null

    Write-Host "  Subscription 'animals' created successfully with filter: speciesType = 'animals'" -ForegroundColor Green
}

# ---------------------------------------------------------------------------
# Subscription: humans
# SQL filter: speciesType = 'humans'
# Used by: HumanSubscription project
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "--- Subscription: humans ---" -ForegroundColor Cyan

Write-Host "  Checking if subscription 'humans' exists..." -ForegroundColor Yellow
$existingHumans = az servicebus topic subscription show `
    --name "humans" `
    --topic-name $TopicName `
    --namespace-name $Namespace `
    --resource-group $ResourceGroup `
    --query "name" -o tsv 2>$null

if ($existingHumans) {
    Write-Host "  Subscription 'humans' already exists, skipping." -ForegroundColor Green
} else {
    Write-Host "  Subscription 'humans' not found." -ForegroundColor Yellow
    Write-Host "  Creating subscription 'humans'..." -ForegroundColor Yellow
    az servicebus topic subscription create `
        --name "humans" `
        --topic-name $TopicName `
        --namespace-name $Namespace `
        --resource-group $ResourceGroup | Out-Null

    Write-Host "  Removing default filter rule '`$Default'..." -ForegroundColor Yellow
    az servicebus topic subscription rule delete `
        --name '$Default' `
        --subscription-name "humans" `
        --topic-name $TopicName `
        --namespace-name $Namespace `
        --resource-group $ResourceGroup | Out-Null

    Write-Host "  Adding SQL filter rule 'HumansFilter' (speciesType = 'humans')..." -ForegroundColor Yellow
    az servicebus topic subscription rule create `
        --name "HumansFilter" `
        --subscription-name "humans" `
        --topic-name $TopicName `
        --namespace-name $Namespace `
        --resource-group $ResourceGroup `
        --filter-sql-expression "speciesType = 'humans'" | Out-Null

    Write-Host "  Subscription 'humans' created successfully with filter: speciesType = 'humans'" -ForegroundColor Green
}

# ---------------------------------------------------------------------------
# Subscription: auditlog
# TrueFilter (default $Default rule) - receives ALL messages regardless of speciesType
# Used by: AuditSubscription project
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "--- Subscription: auditlog ---" -ForegroundColor Cyan

Write-Host "  Checking if subscription 'auditlog' exists..." -ForegroundColor Yellow
$existingAudit = az servicebus topic subscription show `
    --name "auditlog" `
    --topic-name $TopicName `
    --namespace-name $Namespace `
    --resource-group $ResourceGroup `
    --query "name" -o tsv 2>$null

if ($existingAudit) {
    Write-Host "  Subscription 'auditlog' already exists, skipping." -ForegroundColor Green
} else {
    Write-Host "  Subscription 'auditlog' not found." -ForegroundColor Yellow
    Write-Host "  Creating subscription 'auditlog'..." -ForegroundColor Yellow
    az servicebus topic subscription create `
        --name "auditlog" `
        --topic-name $TopicName `
        --namespace-name $Namespace `
        --resource-group $ResourceGroup | Out-Null
    Write-Host "  Subscription 'auditlog' created successfully (TrueFilter - receives all messages)." -ForegroundColor Green
}

Write-Host ""
Write-Host "=== Setup Complete ===" -ForegroundColor Cyan
Write-Host ""

# ---------------------------------------------------------------------------
# Step 5: Verify and update project secrets for the selected namespace
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "--- Verifying Project Secrets ---" -ForegroundColor Cyan
Write-Host "  Retrieving primary connection string for '$Namespace'..." -ForegroundColor Yellow

$ConnectionString = az servicebus namespace authorization-rule keys list `
    --name "RootManageSharedAccessKey" `
    --namespace-name $Namespace `
    --resource-group $ResourceGroup `
    --subscription $SubscriptionId `
    --query "primaryConnectionString" -o tsv 2>$null

if (-not $ConnectionString) {
    Write-Error "Failed to retrieve connection string for namespace '$Namespace'."
    exit 1
}

Write-Host "  Connection string retrieved." -ForegroundColor Green
Write-Host ""

# Paths to every .NET project that uses ConnectionStrings:ServiceBusConnectionString
$dotnetProjects = @(
    "$PSScriptRoot\ServiceBusTopicsDemoSolution\ServiceBusTopicsDemo\ServiceBusTopicsDemo.csproj",
    "$PSScriptRoot\ServiceBusTopicsDemoSolution\AnimalSubscription\AnimalSubscription.csproj",
    "$PSScriptRoot\ServiceBusTopicsDemoSolution\AuditSubscription\AuditSubscription.csproj",
    "$PSScriptRoot\ServiceBusTopicsDemoSolution\HumanSubscription\HumanSubscription.csproj",
    "$PSScriptRoot\ServiceBusQueuesDemoSolution\ServiceBusQueuesDemo\ServiceBusQueuesDemo.csproj",
    "$PSScriptRoot\ServiceBusQueuesDemoSolution\QueueReceiverDemo\QueueReceiverDemo.csproj"
)

foreach ($projectPath in $dotnetProjects) {
    $projectName = Split-Path $projectPath -LeafBase
    Write-Host "  [$projectName] Checking connection string in user secrets..." -ForegroundColor Yellow

    dotnet user-secrets init --project $projectPath | Out-Null

    # Read existing secrets and find the current value (if any)
    $secretsList   = dotnet user-secrets list --project $projectPath 2>$null
    $existingValue = $null
    foreach ($line in $secretsList) {
        if ($line -match "^ConnectionStrings:ServiceBusConnectionString\s*=\s*(.+)$") {
            $existingValue = $Matches[1].Trim()
            break
        }
    }

    if ($existingValue -eq $ConnectionString) {
        Write-Host "  [$projectName] Connection string is already up to date, skipping." -ForegroundColor Green
    } else {
        if ($existingValue) {
            Write-Host "  [$projectName] Connection string mismatch — updating..." -ForegroundColor Yellow
        } else {
            Write-Host "  [$projectName] Connection string not found — writing..." -ForegroundColor Yellow
        }
        dotnet user-secrets set "ConnectionStrings:ServiceBusConnectionString" $ConnectionString --project $projectPath | Out-Null
        if ($LASTEXITCODE -ne 0) {
            Write-Host "  [$projectName] WARNING: Failed to set user secret." -ForegroundColor Red
        } else {
            Write-Host "  [$projectName] Secret updated successfully." -ForegroundColor Green
        }
    }
}

# Verify / update local.settings.json for the Azure Functions project
$localSettingsPath = "$PSScriptRoot\AzureFunctionsServiceBusDemoSolution\AzureFunctionsServiceBusDemo\local.settings.json"

Write-Host ""
Write-Host "  [AzureFunctionsServiceBusDemo] Checking local.settings.json..." -ForegroundColor Yellow

if (Test-Path $localSettingsPath) {
    $settings = Get-Content $localSettingsPath -Raw | ConvertFrom-Json
    if ($settings.Values.ServiceBusConnectionString -eq $ConnectionString) {
        Write-Host "  [AzureFunctionsServiceBusDemo] Connection string is already up to date, skipping." -ForegroundColor Green
    } else {
        if ($settings.Values.ServiceBusConnectionString) {
            Write-Host "  [AzureFunctionsServiceBusDemo] Connection string mismatch — updating..." -ForegroundColor Yellow
        } else {
            Write-Host "  [AzureFunctionsServiceBusDemo] Connection string not found — writing..." -ForegroundColor Yellow
        }
        $settings.Values.ServiceBusConnectionString = $ConnectionString
        $settings | ConvertTo-Json -Depth 3 | Set-Content $localSettingsPath -Encoding UTF8
        Write-Host "  [AzureFunctionsServiceBusDemo] local.settings.json updated successfully." -ForegroundColor Green
    }
} else {
    # File doesn't exist — create it with the minimum required structure
    Write-Host "  [AzureFunctionsServiceBusDemo] local.settings.json not found — creating..." -ForegroundColor Yellow
    $newSettings = [PSCustomObject]@{
        IsEncrypted = $false
        Values      = [PSCustomObject]@{
            AzureWebJobsStorage        = "UseDevelopmentStorage=true"
            ServiceBusConnectionString = $ConnectionString
            FUNCTIONS_WORKER_RUNTIME   = "dotnet-isolated"
        }
    }
    New-Item -ItemType Directory -Force -Path (Split-Path $localSettingsPath) | Out-Null
    $newSettings | ConvertTo-Json -Depth 3 | Set-Content $localSettingsPath -Encoding UTF8
    Write-Host "  [AzureFunctionsServiceBusDemo] local.settings.json created successfully." -ForegroundColor Green
}

Write-Host ""
Write-Host "=== Secrets Verification Complete ===" -ForegroundColor Cyan
Write-Host ""

# ---------------------------------------------------------------------------
# Step 6: Verify AzureWebJobsStorage in local.settings.json
# If it is missing, empty, or the development placeholder, prompt the user to
# pick a real Azure Storage account from the subscription.
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "--- Verifying AzureWebJobsStorage ---" -ForegroundColor Cyan

$currentStorage = $null
if (Test-Path $localSettingsPath) {
    $storageSettings = Get-Content $localSettingsPath -Raw | ConvertFrom-Json
    $currentStorage  = $storageSettings.Values.AzureWebJobsStorage
}

$needsStorage = [string]::IsNullOrWhiteSpace($currentStorage) -or
                $currentStorage -eq "UseDevelopmentStorage=true"      -or
                ($currentStorage -match '^\s*<.*>\s*$')

if (-not $needsStorage) {
    Write-Host "  [AzureFunctionsServiceBusDemo] AzureWebJobsStorage is already set, skipping." -ForegroundColor Green
} else {
    Write-Host "  [AzureFunctionsServiceBusDemo] AzureWebJobsStorage is not configured — fetching storage accounts..." -ForegroundColor Yellow

    $storageAccountNames   = az storage account list `
        --subscription $SubscriptionId `
        --query "[].name" -o tsv 2>$null

    $storageAccountRGs     = az storage account list `
        --subscription $SubscriptionId `
        --query "[].resourceGroup" -o tsv 2>$null

    $storageAccountLocs    = az storage account list `
        --subscription $SubscriptionId `
        --query "[].location" -o tsv 2>$null

    $storageNameList = @($storageAccountNames)
    $storageRGList   = @($storageAccountRGs)
    $storageLocList  = @($storageAccountLocs)

    if ($storageNameList.Count -eq 0) {
        Write-Host "  WARNING: No storage accounts found in subscription '$SubscriptionId'. AzureWebJobsStorage was not updated." -ForegroundColor Red
    } else {
        # Build display strings: "accountName | resourceGroup | location"
        $storageDisplayList = for ($i = 0; $i -lt $storageNameList.Count; $i++) {
            "$($storageNameList[$i]) | $($storageRGList[$i]) | $($storageLocList[$i])"
        }

        $selectedStorageDisplay = Select-FromList `
            -Prompt "Select a Storage Account for AzureWebJobsStorage (subscription: $SubscriptionId):" `
            -Items @($storageDisplayList)

        $selectedStorageIndex = [Array]::IndexOf(@($storageDisplayList), $selectedStorageDisplay)
        $selectedStorageName  = $storageNameList[$selectedStorageIndex]

        Write-Host "  Selected: $selectedStorageName" -ForegroundColor Green
        Write-Host "  Retrieving connection string for '$selectedStorageName'..." -ForegroundColor Yellow

        $StorageConnectionString = az storage account show-connection-string `
            --name $selectedStorageName `
            --subscription $SubscriptionId `
            --query "connectionString" -o tsv 2>$null

        if (-not $StorageConnectionString) {
            Write-Host "  WARNING: Failed to retrieve connection string for '$selectedStorageName'. AzureWebJobsStorage was not updated." -ForegroundColor Red
        } else {
            $storageSettings.Values.AzureWebJobsStorage = $StorageConnectionString
            $storageSettings | ConvertTo-Json -Depth 3 | Set-Content $localSettingsPath -Encoding UTF8
            Write-Host "  [AzureFunctionsServiceBusDemo] AzureWebJobsStorage updated successfully." -ForegroundColor Green
        }
    }
}

Write-Host ""
Write-Host "=== Setup Complete ===" -ForegroundColor Cyan
Write-Host ""
