# ServiceBusTopicsDemoSolution

A **.NET solution** demonstrating Azure Service Bus **topic-based publish/subscribe** messaging. The solution includes a publisher Web API and three independent subscriber console applications, each consuming messages from a different topic subscription with distinct filter rules.

## Solution Architecture

```mermaid
graph TB
    Client["REST Client\n(Swagger UI)"]

    subgraph Publisher
        API["ServiceBusTopicsDemo\nASP.NET Core Web API"]
    end

    subgraph Azure["Azure Service Bus: testmessagetopic"]
        Animals["animals subscription\nFilter: speciesType = 'animals'"]
        Humans["humans subscription\nFilter: speciesType = 'humans'"]
        Audit["auditlog subscription\nTrueFilter (all messages)"]
    end

    subgraph Subscribers
        AnimalSub["AnimalSubscription\n.NET Console App"]
        HumanSub["HumanSubscription\n.NET Console App"]
        AuditSub["AuditSubscription\n.NET Console App"]
    end

    DLQ_Animals["Dead Letter Queue\n(animals/$deadletterqueue)"]
    DLQ_Humans["Dead Letter Queue\n(humans/$deadletterqueue)"]
    DLQ_Audit["Dead Letter Queue\n(auditlog/$deadletterqueue)"]

    Client -->|"POST /api/v1/testmessages\n?speciesType=animals or humans"| API
    Client -->|"POST /api/v1/labeledMessages\n?subjectValue=X"| API
    API -->|"Publishes with speciesType\napplication property"| Animals
    API -->|"Publishes with speciesType\napplication property"| Humans
    API -->|"All messages"| Audit
    Animals -->|"ServiceBusProcessor"| AnimalSub
    Humans -->|"ServiceBusProcessor"| HumanSub
    Audit -->|"ServiceBusProcessor"| AuditSub
    AnimalSub -->|"'exception' or 'fail'"| DLQ_Animals
    HumanSub -->|"'exception' or 'fail'"| DLQ_Humans
    AuditSub -->|"'exception' or 'fail'"| DLQ_Audit
```

## Projects

### `ServiceBusTopicsDemo` — ASP.NET Core Web API (Publisher)

An ASP.NET Core Web API that publishes messages to the `testmessagetopic` Azure Service Bus topic. Provides two endpoints for different routing strategies:

- **`POST /api/v1/testmessages`** — Sets the `speciesType` application property on the message to route it to the correct subscription via filter rules.
- **`POST /api/v1/labeledMessages`** — Sets `message.Subject` for label/subject-based routing.

Swagger/OpenAPI is enabled for interactive testing. Uses .NET User Secrets for the connection string.

### `AnimalSubscription` — .NET Console App (Subscriber)

Subscribes to the `animals` subscription, which has a filter rule of `speciesType = 'animals'`. Processes messages and demonstrates both automatic dead-lettering (by throwing an exception on `"exception"`) and manual dead-lettering (by calling `DeadLetterMessageAsync` on `"fail"`).

### `HumanSubscription` — .NET Console App (Subscriber)

Subscribes to the `humans` subscription, which has a filter rule of `speciesType = 'humans'`. Same dead-letter handling patterns as `AnimalSubscription`. Only messages with `speciesType = 'humans'` are delivered.

### `AuditSubscription` — .NET Console App (Subscriber)

Subscribes to the `auditlog` subscription, which uses a **TrueFilter** and receives **every message** published to the topic, regardless of application properties. Also logs the `message.Subject` in addition to the message body — demonstrating how the audit subscription can capture routing metadata for compliance or logging purposes.

## Topic Subscription Filter Rules

| Subscription | Filter Rule | Receives Messages From |
|--------------|-------------|----------------------|
| `animals` | `speciesType = 'animals'` | Publisher calls with `?speciesType=animals` |
| `humans` | `speciesType = 'humans'` | Publisher calls with `?speciesType=humans` |
| `auditlog` | TrueFilter | All published messages |

## Dead Letter Queue Demo

All three subscriber applications demonstrate dead-letter queue patterns:

| Message Body | Dead-Letter Method | Description |
|-------------|-------------------|-------------|
| `exception` | Automatic (exception thrown) | Message is retried up to the max delivery count, then automatically moved to the DLQ |
| `fail` | Manual (`DeadLetterMessageAsync`) | Message is immediately moved to the DLQ with reason `"Test Failure"` |

## Setup

A PowerShell script `SetupTopicsAndQueues.ps1` is included in the solution to create the required Azure Service Bus topic and subscriptions with the correct filter rules.

```powershell
.\SetupTopicsAndQueues.ps1
```

## Configuration

All projects use `ConnectionStrings:ServiceBusConnectionString` via `appsettings.json` and .NET User Secrets. Refer to each project's README for the specific User Secrets ID.

## Prerequisites

- .NET 10 SDK
- Azure Service Bus namespace (Standard tier or higher — topics require Standard or Premium)
- Run `SetupTopicsAndQueues.ps1` to provision the topic and subscriptions, or create them manually:
  - Topic: `testmessagetopic`
  - Subscription `animals` with filter `speciesType = 'animals'`
  - Subscription `humans` with filter `speciesType = 'humans'`
  - Subscription `auditlog` with TrueFilter
