# HumanSubscription

A **.NET console application** that subscribes to the `humans` subscription of an Azure Service Bus topic. This project demonstrates message consumption from a filtered topic subscription, including both automatic and manual dead-letter queue routing.

## Architecture

```mermaid
graph LR
    Topic["Azure Service Bus\nTopic: testmessagetopic"]
    Sub["humans subscription\nFilter: speciesType = 'humans'"]
    App["HumanSubscription\n.NET Console App"]
    DLQ["Dead Letter Queue\n(humans/$deadletterqueue)"]
    Console["Console Output"]

    Topic -->|"Messages where\nspeciesType = 'humans'"| Sub
    Sub -->|"ServiceBusProcessor\nPeekLock mode"| App
    App -->|"body = 'exception'\nauto dead-letter on exception"| DLQ
    App -->|"body = 'fail'\nmanual dead-letter"| DLQ
    App -->|"Successful messages"| Console
```

## How It Works

The application creates a `ServiceBusProcessor` that continuously listens to the `humans` subscription of the `testmessagetopic` topic. Messages are received in **PeekLock mode** — the application must explicitly complete, abandon, or dead-letter each message.

### Message Processing

| Message Body | Behavior |
|-------------|---------|
| Any normal text | Decoded from UTF-8, printed to console with timestamp and sequence number, then completed |
| `exception` (case-insensitive) | Throws a `SystemException` — the message is **automatically moved to the dead-letter queue** after exceeding the maximum delivery count |
| `fail` (case-insensitive) | Calls `DeadLetterMessageAsync` — the message is **immediately and manually moved to the dead-letter queue** with reason `"Test Failure"` |

### Subscription Filter

This application only receives messages that have the application property `speciesType = 'humans'`. Messages with other `speciesType` values (e.g., `animals`) are not delivered to this subscription.

## Configuration

Configuration is loaded from `appsettings.json` with sensitive values managed via **.NET User Secrets**.

```json
{
  "ConnectionStrings": {
    "ServiceBusConnectionString": "<your-service-bus-connection-string>"
  }
}
```

Set the connection string via User Secrets (recommended for local development):

```bash
dotnet user-secrets set "ConnectionStrings:ServiceBusConnectionString" "<your-connection-string>"
```

User Secrets ID: `33150606-d496-4986-934e-fbc48315aeac`

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `Azure.Messaging.ServiceBus` | 7.20.1 | Azure Service Bus SDK for receiving messages |
| `Microsoft.Extensions.Configuration` | 10.0.7 | Configuration infrastructure |
| `Microsoft.Extensions.Configuration.Abstractions` | 10.0.7 | Configuration abstractions |
| `Microsoft.Extensions.Configuration.UserSecrets` | 10.0.7 | User Secrets support for local development |

## Running the Application

```bash
dotnet run
```

The application starts listening and displays received messages in **white** with timestamps. Press any key to stop the processor.

## Prerequisites

- Azure Service Bus namespace with:
  - Topic named `testmessagetopic`
  - Subscription `humans` with filter rule `speciesType = 'humans'`
- A valid Service Bus connection string with Listen permissions
