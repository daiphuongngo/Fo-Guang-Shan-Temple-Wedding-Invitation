# AuditSubscription

A **.NET console application** that subscribes to the `auditlog` subscription of an Azure Service Bus topic. This subscription uses a **TrueFilter**, meaning it receives **every message** published to the topic regardless of application properties or subject. This project demonstrates an audit/logging pattern using Service Bus topic subscriptions.

## Architecture

```mermaid
graph LR
    Topic["Azure Service Bus\nTopic: testmessagetopic"]
    Sub["auditlog subscription\nFilter: TrueFilter (all messages)"]
    App["AuditSubscription\n.NET Console App"]
    DLQ["Dead Letter Queue\n(auditlog/$deadletterqueue)"]
    Console["Console Output\n(body + Subject/Label)"]

    Topic -->|"ALL messages\n(any speciesType or subject)"| Sub
    Sub -->|"ServiceBusProcessor\nPeekLock mode"| App
    App -->|"body = 'exception'\nauto dead-letter on exception"| DLQ
    App -->|"body = 'fail'\nmanual dead-letter"| DLQ
    App -->|"Successful messages"| Console
```

## How It Works

The application creates a `ServiceBusProcessor` that continuously listens to the `auditlog` subscription of the `testmessagetopic` topic. Because this subscription has a **TrueFilter**, it receives all messages regardless of any application properties or subject values set by the publisher.

### Message Processing

| Message Body | Behavior |
|-------------|---------|
| Any normal text | Decoded from UTF-8, printed to console with timestamp, sequence number, and **Subject/Label value**, then completed |
| `exception` (case-insensitive) | Throws a `SystemException` — the message is **automatically moved to the dead-letter queue** after exceeding the maximum delivery count |
| `fail` (case-insensitive) | Calls `DeadLetterMessageAsync` — the message is **immediately and manually moved to the dead-letter queue** with reason `"Test Failure"` |

### Subject/Label Logging

In addition to the message body, this application also logs the `message.Subject` (also known as the label). This demonstrates how label-based routing metadata can be used for audit logging, allowing you to track the intent or category of each message.

### TrueFilter Subscription

Unlike the `animals` and `humans` subscriptions that use property-filter rules, the `auditlog` subscription has a **TrueFilter** that matches all messages. This makes it ideal for audit logging, monitoring, or compliance use cases where a complete record of all published messages is required.

## Configuration

Configuration is loaded from `appsettings.json` with sensitive values managed via **.NET User Secrets**.

```json
{
  "ConnectionStrings": {
    "ServiceBusConnectionString": "<your-service-bus-connection-string>"
  }
}
```

Set the connection string via User Secrets (recommended for local development):

```bash
dotnet user-secrets set "ConnectionStrings:ServiceBusConnectionString" "<your-connection-string>"
```

User Secrets ID: `a7cdd66f-5100-48be-9269-b73d0fcb7f4b`

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `Azure.Messaging.ServiceBus` | 7.20.1 | Azure Service Bus SDK for receiving messages |
| `Microsoft.Extensions.Configuration` | 10.0.7 | Configuration infrastructure |
| `Microsoft.Extensions.Configuration.Abstractions` | 10.0.7 | Configuration abstractions |
| `Microsoft.Extensions.Configuration.UserSecrets` | 10.0.7 | User Secrets support for local development |

## Running the Application

```bash
dotnet run
```

The application starts listening and displays received messages in **magenta** with timestamps and Subject/Label values. Press any key to stop the processor.

## Prerequisites

- Azure Service Bus namespace with:
  - Topic named `testmessagetopic`
  - Subscription `auditlog` with a TrueFilter rule
- A valid Service Bus connection string with Listen permissions
