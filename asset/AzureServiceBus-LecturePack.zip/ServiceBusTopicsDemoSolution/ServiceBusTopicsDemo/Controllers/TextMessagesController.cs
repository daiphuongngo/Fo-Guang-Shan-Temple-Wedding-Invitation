﻿// CSCI-E94 Fundamendals of cloud computing Service Bus Topics Demo
// Joseph Ficara (c) 2018-2022

using Azure.Messaging.ServiceBus;
using Microsoft.AspNetCore.Mvc;

namespace ServiceBusTopicsDemo.Controllers
{
    /// <summary>
    /// Creates messages in the text message topic
    /// </summary>
    /// <seealso cref="ControllerBase" />
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class TextMessagesController : ControllerBase
    {
        /// <summary>
        /// The configuration instance
        /// </summary>
        private readonly IConfiguration _configuration;

        /// <summary>
        /// The azure service bus topic name
        /// </summary>
        private readonly string _topicName = "testmessagetopic";


        /// <summary>
        /// Gets the service bus connection string.
        /// </summary>
        /// <value>The service bus connection string.</value>
        private string ServiceBusConnectionString
        {
            get
            {
                return _configuration.GetConnectionString("ServiceBusConnectionString");
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TextMessagesController"/> class.
        /// </summary>
        public TextMessagesController(IConfiguration configuration)
        {
            _configuration = configuration;
        }


        /// <summary>
        /// Creates a text message with a species property set to the speciesType
        /// and a message body set to the message.
        /// </summary>
        /// <remarks>
        /// The <c>speciesType</c> application property is used by Service Bus subscription filter rules
        /// to route messages to the correct subscription:
        /// <list type="bullet">
        ///   <item><description><b>animals</b> — routed to the <c>animals</c> subscription (filter: speciesType = 'animals')</description></item>
        ///   <item><description><b>humans</b> — routed to the <c>humans</c> subscription (filter: speciesType = 'humans')</description></item>
        ///   <item><description>Any value — always routed to the <c>auditlog</c> subscription (TrueFilter, receives all messages)</description></item>
        /// </list>
        /// </remarks>
        /// <param name="speciesType">
        /// The species type used to route the message to the correct subscription.
        /// Valid values: <b>animals</b> (routes to animals subscription) or <b>humans</b> (routes to humans subscription).
        /// All messages are also delivered to the auditlog subscription regardless of this value.
        /// Example: animals
        /// </param>
        /// <param name="message">The message content.</param>
        /// <returns>IActionResult</returns>
        [ProducesResponseType(typeof(string), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Route("/api/v1/testmessages")]
        [HttpPost]
        public async Task<IActionResult> Post(string speciesType, [FromBody] string message)
        {
            // 1. Create the Service Bus Client
            ServiceBusClient serviceBusClient = new ServiceBusClient(ServiceBusConnectionString);

            // 2. Create the sender to include the message to send
            ServiceBusSender sender = serviceBusClient.CreateSender(_topicName);
            ServiceBusMessage serviceBusMessage = new ServiceBusMessage(message);
            serviceBusMessage.MessageId = Guid.NewGuid().ToString();
            serviceBusMessage.PartitionKey = Guid.NewGuid().ToString();

            // 3. Add the speciesType application property used by subscription filter rules:
            //    - speciesType = 'animals' routes to the animals subscription
            //    - speciesType = 'humans'  routes to the humans subscription
            //    - All messages also go to the auditlog subscription (TrueFilter)
            serviceBusMessage.ApplicationProperties.Add(key: "speciesType", value: speciesType);

            // 4. Send the message
            await sender.SendMessageAsync(serviceBusMessage);

            // Not providing a URL because we are not providing retrieval support
            return Accepted();
        }

        /// <summary>
        /// Creates a text message with a label property the labelValue
        /// and a message body set to the message
        /// </summary>
        /// <param name="subjectValue">The value of the message subject, also called the label in
        /// the Service Bus Explorer UI. Subscribers can filter on this value using the SQL filter
        /// expression <c>sys.label = 'value'</c> — for example, <c>sys.label = 'Tomato'</c>.
        /// Add this filter to a subscription via the Azure portal under the subscription's Filters settings.</param>
        /// <param name="message">The message content.</param>
        /// <returns>IActionResult</returns>
        [ProducesResponseType(typeof(string), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Route("/api/v1/labeledMessages")]
        [HttpPost]
        public async Task<IActionResult> PostByLabel(string subjectValue, [FromBody] string message)
        {
            // 1. Create the Service Bus Client
            ServiceBusClient serviceBusClient = new ServiceBusClient(ServiceBusConnectionString);

            // 2. Create the sender to include the message to send
            ServiceBusSender sender = serviceBusClient.CreateSender(_topicName);
            ServiceBusMessage serviceBusMessage = new ServiceBusMessage(message);
            serviceBusMessage.MessageId = Guid.NewGuid().ToString();
            serviceBusMessage.PartitionKey = Guid.NewGuid().ToString();

            // 3. Sets the message subject to the labelValue
            serviceBusMessage.Subject = subjectValue;

            // 4. Send the message
            await sender.SendMessageAsync(serviceBusMessage);

            // Not providing a URL because we are not providing retrival support
            return Created("", message);

        }
    }
}
