# ServiceBusTopicsDemo

An **ASP.NET Core Web API** that acts as a message publisher to an Azure Service Bus topic. This project demonstrates topic-based messaging with two routing strategies: application property–based filter routing and message subject (label) routing.

## Architecture

```mermaid
graph LR
    Client["REST Client\n(Swagger UI)"]
    API["ServiceBusTopicsDemo\nASP.NET Core Web API"]
    Topic["Azure Service Bus\nTopic: testmessagetopic"]

    Client -->|"POST /api/v1/testmessages\n?speciesType=animals or humans"| API
    Client -->|"POST /api/v1/labeledMessages\n?subjectValue=X"| API
    API -->|"ServiceBusMessage with\napplication properties or Subject"| Topic
```

## API Endpoints

| Method | Route | Query Parameters | Description |
|--------|-------|-----------------|-------------|
| `POST` | `/api/v1/testmessages` | `speciesType`, `message` (body) | Publishes a message with the `speciesType` application property for filter-based subscription routing |
| `POST` | `/api/v1/labeledMessages` | `subjectValue`, `message` (body) | Publishes a message with `message.Subject` set to the provided label value |

### Property-Based Routing (`/api/v1/testmessages`)

The `speciesType` query parameter is stored as a **Service Bus application property** on the outbound message. Topic subscriptions use filter rules that match this property to control which subscribers receive the message:

| `speciesType` Value | Delivered to Subscription | Filter Rule |
|---------------------|--------------------------|-------------|
| `animals` | `animals` | `speciesType = 'animals'` |
| `humans` | `humans` | `speciesType = 'humans'` |
| Any value | `auditlog` | TrueFilter (receives all messages) |

### Label/Subject-Based Routing (`/api/v1/labeledMessages`)

The `subjectValue` query parameter is set as the `message.Subject` property. This allows identification and routing based on the message subject (also visible as the "label" in Azure Service Bus Explorer).

To filter a subscription so it receives messages with a specific subject, add a SQL filter rule to the subscription in the Azure portal using the `sys.label` system property. For example, to receive messages where the subject is `"Tomato"`:

```sql
sys.label = 'Tomato'
```

#### Adding a SQL Filter Rule via the Azure Portal

1. Navigate to your **Service Bus namespace** in the [Azure portal](https://portal.azure.com).
2. Select your topic (`testmessagetopic`) → **Subscriptions** → select the target subscription.
3. Under **Settings**, click **Filters**.
4. Delete the default `TrueFilter` (rule name `$Default`) if you want exclusive subject-based filtering.
5. Click **+ Add filter** and set:
   - **Filter type**: SQL filter
   - **Filter name**: e.g. `TomatoOnly`
   - **SQL expression**: `sys.label = 'Tomato'`
6. Click **Save**.

After saving, that subscription will only receive messages published via `/api/v1/labeledMessages?subjectValue=Tomato`.

## Configuration

Connection strings are stored in `appsettings.json` with sensitive values managed via **.NET User Secrets**.

```json
{
  "ConnectionStrings": {
    "ServiceBusConnectionString": "<your-service-bus-connection-string>"
  }
}
```

Set the connection string via User Secrets (recommended for local development):

```bash
dotnet user-secrets set "ConnectionStrings:ServiceBusConnectionString" "<your-connection-string>"
```

User Secrets ID: `bce30f8e-c8fc-4d97-9595-9d688f47d22c`

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `Azure.Messaging.ServiceBus` | 7.20.1 | Azure Service Bus SDK for publishing messages to topics |
| `Swashbuckle.AspNetCore` | 10.1.7 | Swagger/OpenAPI UI and XML documentation support |

## Running the Application

```bash
dotnet run
```

The Swagger UI is available at `https://localhost:{port}/swagger` for interactive API testing. Use the Swagger UI to test both endpoints with different `speciesType` values to observe message routing to different subscriptions.

## Prerequisites

- Azure Service Bus namespace with:
  - Topic named `testmessagetopic`
  - Subscription `animals` with filter rule `speciesType = 'animals'`
  - Subscription `humans` with filter rule `speciesType = 'humans'`
  - Subscription `auditlog` with a TrueFilter rule
- A valid Service Bus connection string with Send permissions
