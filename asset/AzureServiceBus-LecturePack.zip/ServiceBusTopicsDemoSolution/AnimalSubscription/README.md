# AnimalSubscription

A **.NET console application** that subscribes to the `animals` subscription of an Azure Service Bus topic. This project demonstrates message consumption from a filtered topic subscription, including both automatic and manual dead-letter queue routing.

## Architecture

```mermaid
graph LR
    Topic["Azure Service Bus\nTopic: testmessagetopic"]
    Sub["animals subscription\nFilter: speciesType = 'animals'"]
    App["AnimalSubscription\n.NET Console App"]
    DLQ["Dead Letter Queue\n(animals/$deadletterqueue)"]
    Console["Console Output"]

    Topic -->|"Messages where\nspeciesType = 'animals'"| Sub
    Sub -->|"ServiceBusProcessor\nPeekLock mode"| App
    App -->|"body = 'exception'\nauto dead-letter on exception"| DLQ
    App -->|"body = 'fail'\nmanual dead-letter"| DLQ
    App -->|"Successful messages"| Console
```

## How It Works

The application creates a `ServiceBusProcessor` that continuously listens to the `animals` subscription of the `testmessagetopic` topic. Messages are received in **PeekLock mode** — the application must explicitly complete, abandon, or dead-letter each message.

### Message Processing

| Message Body | Behavior |
|-------------|---------|
| Any normal text | Decoded from UTF-8, printed to console with timestamp and sequence number, then completed |
| `exception` (case-insensitive) | Throws a `SystemException` — the message is **automatically moved to the dead-letter queue** after exceeding the maximum delivery count |
| `fail` (case-insensitive) | Calls `DeadLetterMessageAsync` — the message is **immediately and manually moved to the dead-letter queue** with reason `"Test Failure"` |

### Subscription Filter

This application only receives messages that have the application property `speciesType = 'animals'`. Messages with other `speciesType` values (e.g., `humans`) are not delivered to this subscription.

## Configuration

Configuration is loaded from `appsettings.json` with sensitive values managed via **.NET User Secrets**.

```json
{
  "ConnectionStrings": {
    "ServiceBusConnectionString": "<your-service-bus-connection-string>"
  }
}
```

Set the connection string via User Secrets (recommended for local development):

```bash
dotnet user-secrets set "ConnectionStrings:ServiceBusConnectionString" "<your-connection-string>"
```

User Secrets ID: `ca956cc5-4905-4a2b-923f-00ae143e4ed1`

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `Azure.Messaging.ServiceBus` | 7.20.1 | Azure Service Bus SDK for receiving messages |
| `Microsoft.Extensions.Configuration` | 10.0.7 | Configuration infrastructure |
| `Microsoft.Extensions.Configuration.Abstractions` | 10.0.7 | Configuration abstractions |
| `Microsoft.Extensions.Configuration.UserSecrets` | 10.0.7 | User Secrets support for local development |

## Running the Application

```bash
dotnet run
```

The application starts listening and displays received messages in **green** with timestamps. Press any key to stop the processor.

## Prerequisites

- Azure Service Bus namespace with:
  - Topic named `testmessagetopic`
  - Subscription `animals` with filter rule `speciesType = 'animals'`
- A valid Service Bus connection string with Listen permissions
