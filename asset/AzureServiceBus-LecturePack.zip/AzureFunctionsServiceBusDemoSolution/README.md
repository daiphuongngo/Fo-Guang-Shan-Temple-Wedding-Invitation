# AzureFunctionsServiceBusDemoSolution

A **.NET solution** demonstrating **serverless Azure Service Bus message processing** using Azure Functions v4 on .NET 10. The solution pairs a publisher Web API (`ServiceBusTopicsDemo`) with a serverless subscriber (`AzureFunctionsServiceBusDemo`) that is triggered automatically when messages arrive on the Service Bus topic.

## Solution Architecture

```mermaid
graph LR
    Client["REST Client\n(Swagger UI)"]

    subgraph Publisher
        API["ServiceBusTopicsDemo\nASP.NET Core Web API\n(.NET 8)"]
    end

    subgraph AzureServiceBus["Azure Service Bus: testmessagetopic"]
        Sub["animals subscription\nFilter: speciesType = 'animals'"]
    end

    subgraph FunctionsApp["AzureFunctionsServiceBusDemo\nAzure Functions v4 (.NET 10 Isolated Worker)"]
        Func["AnimalsSubscriptionFunction\nServiceBusTrigger"]
    end

    DLQ["Dead Letter Queue\n(animals/$deadletterqueue)"]
    Logs["Console / Azure Monitor Logs"]

    Client -->|"POST /api/v1/testmessages\n?speciesType=animals"| API
    Client -->|"POST /api/v1/labeledMessages\n?subjectValue=X"| API
    API -->|"Publishes ServiceBusMessage\nwith speciesType application property"| Sub
    Sub -->|"ServiceBusTrigger\n(event-driven invocation)"| Func
    Func -->|"body = 'exception'\nthrows Exception"| DLQ
    Func -->|"Successful processing"| Logs
```

## Projects

### `ServiceBusTopicsDemo` — ASP.NET Core Web API (Publisher)

The publisher Web API that sends messages to the `testmessagetopic` Azure Service Bus topic. Provides two POST endpoints:

- **`POST /api/v1/testmessages`** — Publishes a message with the `speciesType` application property. When `speciesType=animals`, the message is routed to the `animals` subscription and triggers the Azure Function.
- **`POST /api/v1/labeledMessages`** — Publishes a message with `message.Subject` set for label-based routing.

Swagger/OpenAPI is enabled for interactive testing.

> This project is physically located in the `ServiceBusTopicsDemoSolution` and is shared between both solutions.

### `AzureFunctionsServiceBusDemo` — Azure Functions v4 (.NET 10, Subscriber)

A serverless Azure Functions application hosting the `AnimalsSubscriptionFunction`. The function uses a `ServiceBusTrigger` and is invoked automatically by the Azure Functions runtime whenever a message arrives in the `animals` subscription.

| Property | Value |
|----------|-------|
| Function | `AnimalsSubscriptionFunction` |
| Trigger | `ServiceBusTrigger` |
| Topic | `testmessagetopic` |
| Subscription | `animals` |
| Runtime | Azure Functions v4, .NET 10 Isolated Worker |

The function demonstrates dead-letter queue handling: if the message body is `"exception"`, an exception is thrown and the message is automatically moved to the dead-letter queue by the Functions runtime after exhausting retries.

## Message Flow

1. A REST client calls `POST /api/v1/testmessages?speciesType=animals` on the `ServiceBusTopicsDemo` Web API
2. The Web API publishes a `ServiceBusMessage` with the `speciesType = 'animals'` application property to the `testmessagetopic` topic
3. The `animals` subscription filter rule (`speciesType = 'animals'`) matches the message and delivers it to the subscription
4. The Azure Functions runtime detects the new message via the `ServiceBusTrigger` and invokes `AnimalsSubscriptionFunction`
5. The function processes the message (or dead-letters it if the body is `"exception"`)

## Configuration

### ServiceBusTopicsDemo (Publisher)

Uses `appsettings.json` with .NET User Secrets:
```json
{
  "ConnectionStrings": {
    "ServiceBusConnectionString": "<your-service-bus-connection-string>"
  }
}
```

### AzureFunctionsServiceBusDemo (Subscriber)

Uses `local.settings.json` (not committed to source control):
```json
{
  "IsEncrypted": false,
  "Values": {
    "FUNCTIONS_WORKER_RUNTIME": "dotnet-isolated",
    "ServiceBusConnectionString": "<your-service-bus-connection-string>"
  }
}
```

## Prerequisites

- [.NET 10 SDK](https://dotnet.microsoft.com/download) (for the Functions project)
- [.NET 8 SDK](https://dotnet.microsoft.com/download) (for the publisher project)
- [Azure Functions Core Tools v4](https://learn.microsoft.com/azure/azure-functions/functions-run-local)
- Azure Service Bus namespace (Standard tier or higher) with:
  - Topic: `testmessagetopic`
  - Subscription `animals` with filter rule `speciesType = 'animals'`
