using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace AzureFunctionsServiceBusDemo
{
    public class ServiceBusMessageProcessor
    {
        const string Topic = "testmessagetopic";
        const string Subscription = "animals";

        private readonly ILogger _logger;

        public ServiceBusMessageProcessor(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<ServiceBusMessageProcessor>();
        }

        [Function("AnimalsSubscriptionFunction")]
        public void Run([ServiceBusTrigger(topicName: Topic,
                                                  subscriptionName:Subscription,
                                                  Connection = "ServiceBusConnectionString")] string message)
        {
            // Causes message to go to the dead letter queue
            if (message == "exception")
            {
                throw new Exception("Something bad happened");
            }

            Console.WriteLine(new String('+', 80));
            Console.Write($"\nTopic: [{Topic}] subscription: [{Subscription}]");
            Console.WriteLine($" Message: [{message}]\n");
            Console.WriteLine(new String('-', 80));
        }
    }
}
