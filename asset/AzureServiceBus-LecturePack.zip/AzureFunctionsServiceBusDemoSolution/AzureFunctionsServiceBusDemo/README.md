# AzureFunctionsServiceBusDemo

An **Azure Functions v4 (.NET 10) application** that subscribes to the `animals` subscription of an Azure Service Bus topic using a `ServiceBusTrigger`. This project demonstrates serverless, event-driven message processing with dead-letter queue handling.

## Architecture

```mermaid
graph LR
    Topic["Azure Service Bus\nTopic: testmessagetopic"]
    Sub["animals subscription\nFilter: speciesType = 'animals'"]
    Func["AnimalsSubscriptionFunction\nAzure Functions v4\n.NET 10 Isolated Worker"]
    DLQ["Dead Letter Queue\n(animals/$deadletterqueue)"]
    Logs["Console Output\n/ Azure Monitor"]

    Topic -->|"Messages where\nspeciesType = 'animals'"| Sub
    Sub -->|"ServiceBusTrigger\n(event-driven invocation)"| Func
    Func -->|"body = 'exception'\nthrows Exception"| DLQ
    Func -->|"Successful processing"| Logs
```

## Function Details

### `AnimalsSubscriptionFunction`

| Property | Value |
|----------|-------|
| Function Name | `AnimalsSubscriptionFunction` |
| Trigger | `ServiceBusTrigger` |
| Topic | `testmessagetopic` |
| Subscription | `animals` |
| Connection Setting | `ServiceBusConnectionString` |
| Runtime | Azure Functions v4, .NET 10 Isolated Worker |

The function is invoked automatically by the Azure Functions runtime whenever a message is available in the `animals` subscription. The trigger handles connection management, retry logic, and lock renewal transparently.

### Message Processing

| Message Body | Behavior |
|-------------|---------|
| Any normal text | Printed to console with topic and subscription context, then completed |
| `exception` (exact match) | Throws an `Exception` — the message is **automatically moved to the dead-letter queue** by the Functions runtime after exceeding the maximum delivery count |

## Configuration

Configuration is stored in `local.settings.json` for local development (not committed to source control). The `ServiceBusConnectionString` setting must be a valid Azure Service Bus connection string with Listen permissions.

```json
{
  "IsEncrypted": false,
  "Values": {
    "AzureFunctionsJobHost": "",
    "FUNCTIONS_WORKER_RUNTIME": "dotnet-isolated",
    "ServiceBusConnectionString": "<your-service-bus-connection-string>"
  }
}
```

> **Note:** `local.settings.json` is never published to Azure. When deployed, configure the `ServiceBusConnectionString` application setting in the Azure Functions app configuration.

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `Azure.Messaging.ServiceBus` | 7.20.1 | Azure Service Bus SDK |
| `Microsoft.Azure.Functions.Worker` | 2.52.0 | Azure Functions Isolated Worker host |
| `Microsoft.Azure.Functions.Worker.Extensions.Http.AspNetCore` | 2.1.0 | ASP.NET Core integration for Functions v4 Worker |
| `Microsoft.Azure.Functions.Worker.Extensions.ServiceBus` | 5.24.0 | Service Bus trigger and binding extension |
| `Microsoft.Azure.Functions.Worker.Extensions.EventHubs` | 6.5.0 | Event Hubs extension (available for future use) |
| `Microsoft.Azure.Functions.Worker.Sdk` | 2.0.7 | Build tooling for .NET Isolated Worker |

## Running Locally

Requires [Azure Functions Core Tools](https://learn.microsoft.com/azure/azure-functions/functions-run-local) v4.

```bash
func start
```

The function host starts, registers the `AnimalsSubscriptionFunction` trigger, and begins listening for messages on the `animals` subscription.

## Prerequisites

- [.NET 10 SDK](https://dotnet.microsoft.com/download)
- [Azure Functions Core Tools v4](https://learn.microsoft.com/azure/azure-functions/functions-run-local)
- Azure Service Bus namespace with:
  - Topic named `testmessagetopic`
  - Subscription `animals` with filter rule `speciesType = 'animals'`
- A valid Service Bus connection string with Listen permissions
