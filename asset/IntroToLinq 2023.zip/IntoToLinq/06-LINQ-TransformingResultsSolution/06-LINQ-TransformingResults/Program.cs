﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ_TransformingResults
{
    class Program
    {
        /// <summary>
        /// Defines the person
        /// </summary>
        public class Person
        {
            /// <summary>
            /// Defines the occupations a person can have
            /// </summary>
            public enum Occupations
            {
                Scientist,
                SoftwareEngineer,
                Astronaut
            }

            public int PersonID { get; set; }
            public string Name { get; set; }
            public int Age { get; set; }
            public string PhoneNumber { get; set; }
            public Occupations Occupation { get; set; }

            /// <summary>
            /// Returns a <see cref="System.String"/> a nicely formatted string representing the person's information.
            /// </summary>
            /// <returns>
            /// A <see cref="System.String"/> a nicely formatted string representing the person's information.
            /// </returns>
            public override string ToString()
            {
                StringBuilder sb = new StringBuilder();

                sb.Append(string.Format("  Name       = {0}\n", Name));
                sb.Append(string.Format("  Age        = {0}\n", Age));
                sb.Append(string.Format("  Phone      = {0}\n", PhoneNumber));
                sb.Append(string.Format("  Occupation = {0}\n\n", Occupation));

                return sb.ToString();
            }
        }

        static void Main(string[] args)
        {
            ConsoleKeyInfo menuChoice = DisplayMenuAndGetUserSelection();
            do
            {
                switch (menuChoice.Key)
                {
                    case ConsoleKey.D1:
                        PassingResultsKnownTypes();
                        break;
                    case ConsoleKey.D2:
                        PassingResultsImplicitlyTyped();
                        break;
                }
                menuChoice = DisplayMenuAndGetUserSelection();
            } while (menuChoice.Key != ConsoleKey.Escape);
        }

        /// <summary>
        /// Display menu and get user's choice
        /// </summary>
        /// <returns>The user's menu choice</returns>
        private static ConsoleKeyInfo DisplayMenuAndGetUserSelection()
        {
            Console.Clear();
            Console.WriteLine("Choose 1-2 or ESC to exit program");
            Console.WriteLine("1 - PassingResultsKnownTypes()");
            Console.WriteLine("2 - PassingResultsImplicitlyTyped()");
            Console.WriteLine("ESC - Exit Program");
            return Console.ReadKey();
        }


        /// <summary>
        /// Illustrates passing back a Known type result
        /// </summary>
        static void PassingResultsKnownTypes()
        {           

            Console.Clear();
            Console.WriteLine("Illustrates passing back a known type result\n");

            Console.WriteLine("\n  Display count of people who's age is older than 25 in descending order by age\n");

            IEnumerable<Person> thePeople = GetPeopleOverTwentyFive();

            foreach (var thePerson in thePeople)
            {
                Console.WriteLine(thePerson);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

        }


        /// <summary>
        /// Illustrates a query that returns Known type data
        /// </summary>
        static IEnumerable<Person> GetPeopleOverTwentyFive()
        {

            List<Person> myPeople = new List<Person>()
            {
                new Person {Name = "Bob",     Age = 32, PhoneNumber = "555-1212", Occupation = Person.Occupations.Scientist,  PersonID = 1},
                new Person {Name = "Sue",     Age = 25, PhoneNumber = "555-1313", Occupation = Person.Occupations.SoftwareEngineer, PersonID = 2},
                new Person {Name = "Beth",    Age = 40, PhoneNumber = "555-3232", Occupation = Person.Occupations.Astronaut, PersonID = 3},
                new Person {Name = "Jack",    Age = 54, PhoneNumber = "555-2222", Occupation = Person.Occupations.SoftwareEngineer, PersonID = 4}
            };

           IEnumerable<Person> peopleOlderThanTwentyFive = from person in myPeople where person.Age > 25 orderby person.Age descending select person;

           return peopleOlderThanTwentyFive;
        }


        /// <summary>
        /// Illustrates transforming a result so the result can be passed back via a method return
        /// </summary>
        static void PassingResultsImplicitlyTyped()
        {
            Console.Clear();
            Console.WriteLine("Illustrates transforming an implicitly typed result so the result can be passed back via a method return\n");

            Console.WriteLine("\n  Display count of people who's age is older than 25, returning only their name and age in descending order by age\n");

            Array myArray = AnonymousTypeTransformQuery();
                        

            foreach (var thePerson in myArray)
            {
                Console.WriteLine("  " + thePerson);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

        }

        /// <summary>
        /// Illustrates a query that returns a new type via anonymous types in LINQ
        /// </summary>
        static Array AnonymousTypeTransformQuery()
        {

            List<Person> myPeople = new List<Person>()
            {
                new Person {Name = "Bob",     Age = 32, PhoneNumber = "555-1212", Occupation = Person.Occupations.Scientist,  PersonID = 1},
                new Person {Name = "Sue",     Age = 25, PhoneNumber = "555-1313", Occupation = Person.Occupations.SoftwareEngineer, PersonID = 2},
                new Person {Name = "Beth",    Age = 40, PhoneNumber = "555-3232", Occupation = Person.Occupations.Astronaut, PersonID = 3},
                new Person {Name = "Jack",    Age = 54, PhoneNumber = "555-2222", Occupation = Person.Occupations.SoftwareEngineer, PersonID = 4}
            };

            var peopleOlderThanTwentyFive = from person in myPeople where person.Age > 25 orderby person.Age descending select new { person.Name, person.Age };

            return peopleOlderThanTwentyFive.ToArray();
        }

    }
}
