﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ_QueryOperators
{
    class Program
    {
        /// <summary>
        /// Defines an order
        /// </summary>
        public class Order
        {
            public int OrderNumber { get; set; }
            public string Description { get; set; }
            public decimal Total { get; set; }
            public int PersonID { get; set; }
        }

        /// <summary>
        /// Defines the order details
        /// </summary>
        public class OrderDetail
        {
            public int OrderNumber { get; set; }
            public int PersonID { get; set; }
            public string Description { get; set; }
        }

        /// <summary>
        /// Defines a person
        /// </summary>
        public class Person
        {
            /// <summary>
            /// Defines the occupations a person can have
            /// </summary>
            public enum Occupations
            {
                Scientist,
                SoftwareEngineer,
                Astronaut
            }

            public int PersonID { get; set; }
            public string Name { get; set; }
            public int Age { get; set; }
            public string PhoneNumber { get; set; }
            public Occupations Occupation { get; set; }

            /// <summary>
            /// Returns a <see cref="System.String"/> that is nicely formatted representing the person.
            /// </summary>
            /// <returns>
            /// A <see cref="System.String"/> that is nicely formatted representing the person.
            /// 
            /// </returns>
            public override string ToString()
            {
                StringBuilder sb = new StringBuilder();

                sb.Append(string.Format("  Name       = {0}\n", Name));
                sb.Append(string.Format("  Age        = {0}\n", Age));
                sb.Append(string.Format("  Phone      = {0}\n", PhoneNumber));
                sb.Append(string.Format("  Occupation = {0}\n\n", Occupation));

                return sb.ToString();
            }
        }


        /// <summary>
        /// Illustrates some of the LINQ Query Operators
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            ConsoleKeyInfo menuChoice = DisplayMenuAndGetUserSelection();
            do
            {
                switch (menuChoice.Key)
                {
                    case ConsoleKey.D1:
                        CountQuery();
                        break;
                    case ConsoleKey.D2:
                        AnonymousTypeTransformQuery();
                        break;
                    case ConsoleKey.D3:
                        InnerJoinQuery();
                        break;
                    case ConsoleKey.D4:
                        LeftOuterJoinQuery();
                        break;
                    case ConsoleKey.D5:
                        InnerJoinQueryCompositeKeys();
                        break;
                    case ConsoleKey.D6:
                        SetDifferenceQuery();
                        break;
                    case ConsoleKey.D7:
                        SetIntersectQuery();
                        break;
                }
                menuChoice = DisplayMenuAndGetUserSelection();
            } while (menuChoice.Key != ConsoleKey.Escape);
        }

        /// <summary>
        /// Display menu and get user's choice
        /// </summary>
        /// <returns>The user's menu choice</returns>
        private static ConsoleKeyInfo DisplayMenuAndGetUserSelection()
        {
            Console.Clear();
            Console.WriteLine("Choose 1-7 or ESC to exit program");
            Console.WriteLine("1 - CountQuery()");
            Console.WriteLine("2 - AnonymousTypeTransformQuery()");
            Console.WriteLine("3 - InnerJoinQuery()");
            Console.WriteLine("4 - LeftOuterJoinQuery()");
            Console.WriteLine("5 - InnerJoinQueryCompositeKeys()");
            Console.WriteLine("6 - SetDifferenceQuery()");
            Console.WriteLine("7 - SetIntersectQuery()");
            Console.WriteLine("ESC - Exit Program");
            return Console.ReadKey();
        }


        /// <summary>
        /// Illustrates a count query in LINQ
        /// </summary>
        static void CountQuery()
        {
            Console.Clear();
            Console.WriteLine("Illustrates a count query in LINQ\n");

            List<Person> myPeople = new List<Person>()
            {
                new Person {Name = "Bob",     Age = 32, PhoneNumber = "555-1212", Occupation = Person.Occupations.Scientist,  PersonID = 1},
                new Person {Name = "Sue",     Age = 25, PhoneNumber = "555-1313", Occupation = Person.Occupations.SoftwareEngineer, PersonID = 2},
                new Person {Name = "Beth",    Age = 40, PhoneNumber = "555-3232", Occupation = Person.Occupations.Astronaut, PersonID = 3},
                new Person {Name = "Jack",    Age = 54, PhoneNumber = "555-2222", Occupation = Person.Occupations.SoftwareEngineer, PersonID = 4}
            };

            Console.WriteLine("  All People:\n");
            foreach (Person thePerson in myPeople)
            {
                Console.WriteLine(thePerson);
            }

            Console.WriteLine("\n  Display count of people who's age is less than (Extension Method Syntax) 30\n");

            // Lambda expression defining filter
            int peopleLessThanThirty = myPeople.Count(person => person.Age < 30);
            Console.WriteLine("  People who's age is less than 30 is: {0}", peopleLessThanThirty);

            Console.WriteLine("\n\n  Display count of people who's age is less than 30 (LINQ Syntax)\n");
            // LINQ Expression's where clause defining filter
            int peopleLessThanThirtyLINQ = (from person in myPeople where person.Age < 30 select person).Count<Person>();
            Console.WriteLine("  People who's age is less than 30 is: {0}", peopleLessThanThirtyLINQ);

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

        }

        /// <summary>
        /// Illustrates a query that returns a new type via anonymous types in LINQ
        /// </summary>
        static void AnonymousTypeTransformQuery()
        {
            Console.Clear();
            Console.WriteLine("Illustrates a query that returns a new type via anonymous types in LINQ\n");

            List<Person> myPeople = new List<Person>()
            {
                new Person {Name = "Bob",     Age = 32, PhoneNumber = "555-1212", Occupation = Person.Occupations.Scientist,  PersonID = 1},
                new Person {Name = "Sue",     Age = 25, PhoneNumber = "555-1313", Occupation = Person.Occupations.SoftwareEngineer, PersonID = 2},
                new Person {Name = "Beth",    Age = 40, PhoneNumber = "555-3232", Occupation = Person.Occupations.Astronaut, PersonID = 3},
                new Person {Name = "Jack",    Age = 54, PhoneNumber = "555-2222", Occupation = Person.Occupations.SoftwareEngineer, PersonID = 4}
            };

            Console.WriteLine("  All People:\n");
            foreach (Person thePerson in myPeople)
            {
                Console.WriteLine(thePerson);
            }

            var peopleOlderThanTwentyFive = from person in myPeople
                                            where person.Age > 25
                                            orderby person.Age descending
                                            select new { person.Name, person.Age };

            Console.WriteLine("\n  Display count of people who's age is older than 25, returning only their name and age in descending order by age\n");

            foreach (var thePerson in peopleOlderThanTwentyFive)
            {
                Console.WriteLine("  " + thePerson);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

        }

        /// <summary>
        /// Illustrates an inner join query in LINQ
        /// </summary>
        static void InnerJoinQuery()
        {
            Console.Clear();
            Console.WriteLine("Illustrates an inner join query in LINQ\n");

            List<Order> myOrders = new List<Order>()
            {
                new Order { OrderNumber=1, Description="Acme Parts 1", Total=1012.34M, PersonID=1},
                new Order { OrderNumber=2, Description="Acme Parts 2", Total=2023.44M, PersonID=2},
                new Order { OrderNumber=3, Description="Acme Parts 3", Total=3034.54M},
                new Order { OrderNumber=4, Description="Acme Parts 4", Total=4045.64M, PersonID=2},
            };

            List<Person> myPeople = new List<Person>()
            {
                new Person {Name = "Bob",     Age = 32, PhoneNumber = "555-1212", Occupation = Person.Occupations.Scientist,  PersonID = 1},
                new Person {Name = "Sue",     Age = 25, PhoneNumber = "555-1313", Occupation = Person.Occupations.SoftwareEngineer, PersonID = 2},
                new Person {Name = "Beth",    Age = 40, PhoneNumber = "555-3232", Occupation = Person.Occupations.Astronaut, PersonID = 3},
                new Person {Name = "Jack",    Age = 54, PhoneNumber = "555-2222", Occupation = Person.Occupations.SoftwareEngineer, PersonID = 4}
            };


            IEnumerable<Person> peopleWithOrders = (from person in myPeople
                                                    join order in myOrders on person.PersonID equals order.PersonID
                                                    select person).Distinct<Person>();

            Console.WriteLine("  Display all people with orders\n");

            foreach (Person thePerson in peopleWithOrders)
            {
                Console.WriteLine(thePerson);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();
        }

        /// <summary>
        /// Illustrates a left outer join query in LINQ
        /// </summary>
        static void LeftOuterJoinQuery()
        {
            Console.Clear();
            Console.WriteLine("Illustrates a left outer join query in LINQ\n");

            List<Order> myOrders = new List<Order>()
            {
                new Order { OrderNumber=1, Description="Acme Parts 1", Total=1012.34M, PersonID=1},
                new Order { OrderNumber=2, Description="Acme Parts 2", Total=2023.44M, PersonID=2},
                new Order { OrderNumber=3, Description="Acme Parts 3", Total=3034.54M},
                new Order { OrderNumber=4, Description="Acme Parts 4", Total=4045.64M, PersonID=2},
            };

            List<Person> myPeople = new List<Person>()
            {
                new Person {Name = "Bob",     Age = 32, PhoneNumber = "555-1212", Occupation = Person.Occupations.Scientist,  PersonID = 1},
                new Person {Name = "Sue",     Age = 25, PhoneNumber = "555-1313", Occupation = Person.Occupations.SoftwareEngineer, PersonID = 2},
                new Person {Name = "Beth",    Age = 40, PhoneNumber = "555-3232", Occupation = Person.Occupations.Astronaut, PersonID = 3},
                new Person {Name = "Jack",    Age = 54, PhoneNumber = "555-2222", Occupation = Person.Occupations.SoftwareEngineer, PersonID = 4}
            };


            var peopleWithOrWithoutOrders = from person in myPeople
                                            join order in myOrders on person.PersonID equals order.PersonID into orderGroup
                                            from item in orderGroup.DefaultIfEmpty(new Order())
                                            select new { PersonName = person.Name, OrderNumber = item.OrderNumber, OrderDescription = item.Description };

            Console.WriteLine("  Display all people with or without orders, along with the order information\n");

            foreach (var orderInfo in peopleWithOrWithoutOrders)
            {
                Console.WriteLine("  " + orderInfo);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();
        }

        /// <summary>
        /// Illustrates an inner join query in LINQ with composite keys
        /// </summary>
        static void InnerJoinQueryCompositeKeys()
        {
            Console.Clear();
            Console.WriteLine("Illustrates an inner join query in LINQ with composite keys\n");

            List<Order> myOrders = new List<Order>()
            {
                new Order { OrderNumber=1, Description="Acme Parts 1", Total=1012.34M, PersonID=1},
                new Order { OrderNumber=2, Description="Acme Parts 2", Total=2023.44M, PersonID=2},
                new Order { OrderNumber=3, Description="Acme Parts 3", Total=3034.54M, PersonID=42},
                new Order { OrderNumber=4, Description="Acme Parts 4", Total=4045.64M, PersonID=2},
            };

            List<OrderDetail> myOrderDetails = new List<OrderDetail>()
            {
                new OrderDetail { OrderNumber=1, Description="Saw", PersonID=1},
                new OrderDetail { OrderNumber=2, Description="Phone", PersonID=2},
                new OrderDetail { OrderNumber=3, Description="Book", PersonID=42},
                new OrderDetail { OrderNumber=4, Description="Grill", PersonID=2},
            };

            List<Person> myPeople = new List<Person>()
            {
                new Person {Name = "Bob",     Age = 32, PhoneNumber = "555-1212", Occupation = Person.Occupations.Scientist,  PersonID = 1},
                new Person {Name = "Sue",     Age = 25, PhoneNumber = "555-1313", Occupation = Person.Occupations.SoftwareEngineer, PersonID = 2},
                new Person {Name = "Beth",    Age = 40, PhoneNumber = "555-3232", Occupation = Person.Occupations.Astronaut, PersonID = 3},
                new Person {Name = "Jack",    Age = 54, PhoneNumber = "555-2222", Occupation = Person.Occupations.SoftwareEngineer, PersonID = 4}
            };

            // Note: The use of "PartName" in the select clause
            // This is necessary because there is already a property called "Description"
            // PartName names the "details.Description" attribute uniquely, which is required for anonymous types.
            var peopleWithOrderDetails = from people in myPeople
                                         from order in myOrders
                                         join orderDetails in myOrderDetails
                                            on new { people.PersonID, order.OrderNumber } equals new { orderDetails.PersonID, orderDetails.OrderNumber } into detailsGroup
                                         from details in detailsGroup
                                         select new { people.Name, order.Description, PartName = details.Description };

            Console.WriteLine("  Display all people with order details\n");

            foreach (var thePersonOrderDetail in peopleWithOrderDetails)
            {
                Console.WriteLine("  " + thePersonOrderDetail);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();
        }

        /// <summary>
        /// Illustrates using the Except extension method to get differences between two sets
        /// </summary>
        static void SetDifferenceQuery()
        {
            Console.Clear();
            Console.WriteLine("Illustrates using the Except extension method to get differences between two sets\n");

            string[] bobsGames = { "Half Life", "Gears of War", "Frogger" };
            string[] suesGames = { "Quake", "Half Life", "Mrs. Packman" };

            Console.WriteLine("  Bob has these games:\n");
            foreach (string bobsGame in bobsGames)
            {
                Console.WriteLine("  " + bobsGame);
            }

            Console.WriteLine("\n  Sue has these games:\n");
            foreach (string suesGame in suesGames)
            {
                Console.WriteLine("  " + suesGame);
            }

            IEnumerable<string> diffGamesBob = bobsGames.Except(suesGames);
            Console.WriteLine("\n  The games bob has that Sue does not have:\n");
            foreach (string diffGame in diffGamesBob)
            {
                Console.WriteLine("  " + diffGame);
            }

            Console.WriteLine("\n  The games Bob has that Sue does not and Sue has that Bob does not have (LINQ/Extension Method Syntax):\n");

            // Games that bob has that sue does not
            IEnumerable<string> diffGames1 = (from bobG in bobsGames select bobG).Except(from sueG in suesGames select sueG);

            // Games that sue has that bob does not
            IEnumerable<string> diffGames2 = (from sueG in suesGames select sueG).Except(from bobG in bobsGames select bobG);

            // Union the two sets
            IEnumerable<string> diffGames = diffGames1.Union(diffGames2);

            foreach (string diffGame in diffGames)
            {
                Console.WriteLine("  " + diffGame);
            }

            Console.WriteLine("\n  The games Bob has that Sue does not and Sue has that Bob does not have (LINQ Syntax):\n");
            IEnumerable<string> diffGamesUnion = (from bobG in bobsGames select bobG).Except(from sueG in suesGames select sueG)
                                                 .Union(
                                                        (from sueG in suesGames select sueG).Except(from bobG in bobsGames select bobG)
                                                        );

            foreach (string diffGame in diffGamesUnion)
            {
                Console.WriteLine("  " + diffGame);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

        }

        /// <summary>
        /// Illustrates using the Intersect extension method to get the intersection between two sets
        /// </summary>
        static void SetIntersectQuery()
        {
            Console.Clear();
            Console.WriteLine("Illustrates using the Intersect extension method to get the intersection between two sets\n");

            string[] bobsGames = { "Half Life", "Gears of War", "Frogger" };
            string[] suesGames = { "Quake", "Half Life", "Mrs. Packman" };

            Console.WriteLine("  Bob has these games:\n");
            foreach (string bobsGame in bobsGames)
            {
                Console.WriteLine("  " + bobsGame);
            }

            Console.WriteLine("\n  Sue has these games:\n");
            foreach (string suesGame in suesGames)
            {
                Console.WriteLine("  " + suesGame);
            }

            IEnumerable<string> intersectGamesBob = bobsGames.Intersect(suesGames);
            Console.WriteLine("\n  The games Bob has that Sue also has, (extension method syntax)\n");
            foreach (string intersectGame in intersectGamesBob)
            {
                Console.WriteLine("  " + intersectGame);
            }

            Console.WriteLine("\n  The games Bob has that Sue also has, (LINQ syntax)\n");

            IEnumerable<string> intersectGamesBobLINQ = (from bobG in bobsGames select bobG).Intersect(from sueG in suesGames select sueG);
            foreach (string intersectGame in intersectGamesBobLINQ)
            {
                Console.WriteLine("  " + intersectGame);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

        }

    }
}
