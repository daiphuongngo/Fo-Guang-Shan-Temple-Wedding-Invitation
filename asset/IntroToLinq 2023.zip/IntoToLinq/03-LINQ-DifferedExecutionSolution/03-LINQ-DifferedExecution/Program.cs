﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ_DifferedExecution
{
    class Program
    {
        /// <summary>
        /// Illustrates Differed and Immediate Execution of queries
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            ConsoleKeyInfo menuChoice = DisplayMenuAndGetUserSelection();
            do
            {
                switch (menuChoice.Key)
                {
                    case ConsoleKey.D1:
                        DifferedExecution();
                        break;
                    case ConsoleKey.D2:
                        ImmediateExecution();
                        break;
                }
                menuChoice = DisplayMenuAndGetUserSelection();
            } while (menuChoice.Key != ConsoleKey.Escape);
        }

        /// <summary>
        /// Display menu and get user's choice
        /// </summary>
        /// <returns>The user's menu choice</returns>
        private static ConsoleKeyInfo DisplayMenuAndGetUserSelection()
        {
            Console.Clear();
            Console.WriteLine("Choose 1-2 or ESC to exit program");
            Console.WriteLine("1 - DifferedExecution()");
            Console.WriteLine("2 - ImmediateExecution()");
            Console.WriteLine("ESC - Exit Program");
            return Console.ReadKey();
        }



        /// <summary>
        /// Illustrates Differed Execution
        /// </summary>
        static void DifferedExecution()
        {
            Console.Clear();
            Console.WriteLine("Illustrates Differed Execution\n");
            int[] myInts = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            IEnumerable<int> intsLessThanSix = from s in myInts 
                                               where s < 6 
                                               select s;

            // Demo Debugger: Step Into... 
            // Note: (Must enable "Just My Code (Managed Only)") in debugger settings for this demo.
            foreach (var item in intsLessThanSix)
            {
                Console.WriteLine("  " + item);
            }

            Console.WriteLine("\nModify second element to contain the value -2\n");
            myInts[1] = -2;

            Console.WriteLine("  Dump out myInts\n");
            foreach (var item in myInts)
            {
                Console.WriteLine("  " + item);
            }

            // Demo Debugger: Step Into...
            // Note: (Must enable "Just My Code (Managed Only)") in debugger settings for this demo.
            Console.WriteLine("\n  Dump out intsLessThanSix\n");
            foreach (var item in intsLessThanSix)
            {
                Console.WriteLine("  " + item);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

        }

        /// <summary>
        /// Illustrates Immediate Execution
        /// </summary>
        static void ImmediateExecution()
        {
            Console.Clear();
            Console.WriteLine("Illustrates Immediate Execution\n");
            int[] myInts = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            int[] intsLessThanSix = (from s in myInts where s < 6 select s).ToArray<int>();

            // Demo Immediate: Step Into...
            foreach (var item in intsLessThanSix)
            {
                Console.WriteLine("  " + item);
            }

            Console.WriteLine("\nModify second element to contain the value -2\n");
            myInts[1] = -2;


            Console.WriteLine("  Dump out myInts\n");
            foreach (var item in myInts)
            {
                Console.WriteLine("  " + item);
            }

            // Demo Immediate: Step Into...
            Console.WriteLine("\n  Dump out intsLessThanSix\n");
            foreach (var item in intsLessThanSix)
            {
                Console.WriteLine("  " + item);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

        }

    }
}
