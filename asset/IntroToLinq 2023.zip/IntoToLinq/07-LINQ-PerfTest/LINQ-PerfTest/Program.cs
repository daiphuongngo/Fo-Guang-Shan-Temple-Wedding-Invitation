﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Linq;

namespace LINQ_PerfTest
{
    class Person
    {
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; }
        /// <summary>
        /// Gets or sets the phone number.
        /// </summary>
        /// <value>The phone number.</value>
        public string PhoneNumber { get; set; }
        /// <summary>
        /// Gets or sets the age.
        /// </summary>
        /// <value>The age.</value>
        public int Age { get; set; }
    }

    class Program
    {
        const int TotalNumberOfElements = 10000000;
        const int MaxRange = 5400000;
        const int MinRange = 5000000;

        /// <summary>
        /// Illustrates performance difference of LINQ vs a Generic Dictionary when filtering using a simple key
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine("Illustrates performance difference of LINQ vs a Generic Dictionary");
            Console.WriteLine("Tests filtering data on an integer.");

            System.Collections.Generic.Dictionary<int, Person> thePeopleGenericDictionary = new Dictionary<int, Person>();
            List<Person> thePeopleGenericList = new List<Person>();

            IEnumerable<Person> theUnFilteredPeopleLINQView = from p in thePeopleGenericList select p;
            IEnumerable<Person> theUnFilteredPeopleLINQViewOfDictionary = from p in thePeopleGenericDictionary select p.Value;
            IEnumerable<Person> theFilteredPeopleLINQView = from p in thePeopleGenericList where p.Age < MaxRange && p.Age >= MinRange select p;

            // Use the Key for our query this doesn't make it faster because its not referencing through the dictionary's hashed index
            IEnumerable<Person> thePeopleGenericDictionaryLINQView = from p in thePeopleGenericDictionary where p.Key < MaxRange && p.Key >= MinRange select p.Value;

            Stopwatch stopWatch = new Stopwatch();

            // Initialize Data 
            InitializeData(thePeopleGenericDictionary, thePeopleGenericList);            

            // Run tests
            TimeSpan LINQViewOfListSetDuration = LINQViewOfCollectionSetTest(theUnFilteredPeopleLINQView, "Entire List");
            TimeSpan GenericListSetDuration = GenericListSetTest(thePeopleGenericList);

            TimeSpan LINQViewOfDictionarySetDuration = LINQViewOfCollectionSetTest(theUnFilteredPeopleLINQViewOfDictionary, "Entire Dictionary");
            TimeSpan GenericDictionarySetTestDuration = GenericDictionarySetTest(thePeopleGenericDictionary);

            TimeSpan LINQSubsetOfListDuration = LINQViewOfCollectionSetTest(theFilteredPeopleLINQView, "Subset of List");
            TimeSpan GenericListSubsetDuration = GenericListSubsetTest(thePeopleGenericList);

            TimeSpan LINQSubsetOfDictionaryDuration = LINQViewOfCollectionSetTest(thePeopleGenericDictionaryLINQView, "Subset of Dictionary");
            TimeSpan GenericSubsetOfDictionaryDuration = GenericSubsetOfDictionaryTest(thePeopleGenericDictionary);

            // Display results
            Console.WriteLine("\n\n");
            Console.WriteLine("LINQEntireList\t{0:N2}\tGenericEntireList\t{1:N2}", LINQViewOfListSetDuration.TotalMilliseconds, GenericListSetDuration.TotalMilliseconds);

            Console.WriteLine("LINQEntireDict\t{0:N2}\tGenericEntireDict\t{1:N2}", LINQViewOfDictionarySetDuration.TotalMilliseconds, GenericDictionarySetTestDuration.TotalMilliseconds);

            Console.WriteLine("LINQSubsetList\t{0:N2}\t\tGenericSubsetList\t{1:N2}", LINQSubsetOfListDuration.TotalMilliseconds, GenericListSubsetDuration.TotalMilliseconds);

            Console.WriteLine("LINQSubsetDict\t{0:N2}\t\tGenericSubsetDict\t{1:N2}", LINQSubsetOfDictionaryDuration.TotalMilliseconds, GenericSubsetOfDictionaryDuration.TotalMilliseconds);

            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();

        }

        /// <summary>
        /// Initializes the data to run the tests on
        /// </summary>
        /// <param name="dictionaryOfPeople">The generic dictionary to populate</param>
        /// <param name="thePeople">The people collection to populate</param>
        private static void InitializeData(System.Collections.Generic.Dictionary<int, Person> dictionaryOfPeople, List<Person> thePeople)
        {
            Console.WriteLine("Initializing: Data...");
            for (int i = 0; i < TotalNumberOfElements; i++)
            {
                Person thePerson = new Person { Age = i, Name = "Name" + i.ToString(), PhoneNumber = "PhoneNumber" + i.ToString() };
                thePeople.Add(thePerson);
                dictionaryOfPeople.Add(thePerson.Age, thePerson);
            }
            Console.WriteLine("Initialization: Complete\n");

            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        /// <summary>
        /// Test on LINQ view of collection...
        /// </summary>
        /// <param name="thePeople">The people to run the test on</param>
        /// <param name="stopWatch">Stopwatch used to time the test</param>
        /// <param name="collectionTypeDescription">A description of the source collection the LINQ query is running against</param>
        private static TimeSpan LINQViewOfCollectionSetTest(IEnumerable<Person> thePeople, string collectionTypeDescription)
        {
            Stopwatch stopWatch = new Stopwatch();
            int count = 0;

            Console.WriteLine("Running: Test on LINQ view of {0} collection...", collectionTypeDescription);

            stopWatch.Start();

            foreach (Person thePerson in thePeople)
            {
                thePerson.PhoneNumber += "x";
                count++;
            }

            stopWatch.Stop();

            Console.WriteLine("count={0} {1}:{2}.{3}", count, stopWatch.Elapsed.Minutes, stopWatch.Elapsed.Seconds, stopWatch.Elapsed.Milliseconds);
            Console.WriteLine("Completed: Test on LINQ view of {0} collection.\n", collectionTypeDescription);

            GC.Collect();
            GC.WaitForPendingFinalizers();

            return stopWatch.Elapsed;

        }

        /// <summary>
        /// Test on the entire generic List collection...
        /// </summary>
        /// <param name="thePeople">The people to run the test on</param>
        /// <param name="stopWatch">Stopwatch used to time the test</param>
        private static TimeSpan GenericListSetTest(List<Person> thePeople)
        {
            Stopwatch stopWatch = new Stopwatch();
            int count = 0;

            Console.WriteLine("Running: Test on the Entire Generic List collection...");

            stopWatch.Start();

            foreach (Person thePerson in thePeople)
            {
                thePerson.PhoneNumber += "q";
                count++;
            }

            stopWatch.Stop();

            Console.WriteLine("count={0} {1}:{2}.{3}", count, stopWatch.Elapsed.Minutes, stopWatch.Elapsed.Seconds, stopWatch.Elapsed.Milliseconds);
            Console.WriteLine("Completed: Test on the Entire Generic List collection.\n");

            GC.Collect();
            GC.WaitForPendingFinalizers();

            return stopWatch.Elapsed;
        }

        /// <summary>
        /// Test on the entire generic dictionary...
        /// </summary>
        /// <param name="dictionaryOfPeople">The dictionary of people to query</param>
        /// <param name="stopWatch">Stopwatch used to time the test</param>
        private static TimeSpan GenericDictionarySetTest(System.Collections.Generic.Dictionary<int, Person> dictionaryOfPeople)
        {
            Console.WriteLine("Running: Test on the Entire Generic Dictionary collection...");
            Stopwatch stopWatch = new Stopwatch();

            stopWatch.Start();

            int count = 0;

            foreach (Person thePerson in dictionaryOfPeople.Values)
            {
                thePerson.PhoneNumber += "x";
                count++;
            }

            stopWatch.Stop();

            Console.WriteLine("count={0} {1}:{2}.{3}", count, stopWatch.Elapsed.Minutes, stopWatch.Elapsed.Seconds, stopWatch.Elapsed.Milliseconds);
            Console.WriteLine("Completed: Test on the Entire Generic Dictionary collection.\n");

            GC.Collect();
            GC.WaitForPendingFinalizers();

            return stopWatch.Elapsed;
        }


        /// <summary>
        /// Test on subset of generic list...
        /// </summary>
        /// <param name="thePeople">The generic list to run test on</param>
        /// <param name="stopWatch">Stopwatch used to time the test</param>
        private static TimeSpan GenericListSubsetTest(List<Person> thePeople)
        {
            Console.WriteLine("Running: Test on a Subset of Generic List collection...");

            int count = 0;
            Stopwatch stopWatch = new Stopwatch();

            stopWatch.Reset();
            stopWatch.Start();

            foreach (Person thePerson in thePeople)
            {
                if (thePerson.Age < MaxRange && thePerson.Age >= MinRange)
                {
                    thePerson.PhoneNumber += "r";
                    count++;
                }
            }

            stopWatch.Stop();

            Console.WriteLine("count={0} {1}:{2}.{3}", count, stopWatch.Elapsed.Minutes, stopWatch.Elapsed.Seconds, stopWatch.Elapsed.Milliseconds);
            Console.WriteLine("Completed: Test on a Subset of Generic List collection.\n");

            GC.Collect();
            GC.WaitForPendingFinalizers();

            return stopWatch.Elapsed;
        }

        /// <summary>
        /// Test on subset of generic dictionary...
        /// </summary>
        /// <param name="dictionaryOfPeople">The dictionary of people to query</param>
        /// <param name="stopWatch">Stopwatch used to time the test</param>        
        private static TimeSpan GenericSubsetOfDictionaryTest(System.Collections.Generic.Dictionary<int, Person> dictionaryOfPeople)
        {
            Console.WriteLine("Running: Test on a Subset of Generic Dictionary collection...");

            int count = 0;
            Stopwatch stopWatch = new Stopwatch();

            stopWatch.Reset();
            stopWatch.Start();

            for (int theKey = MinRange; theKey < MaxRange; theKey++)
            {
                dictionaryOfPeople[theKey].PhoneNumber = "z";
                count++;
            }

            stopWatch.Stop();

            Console.WriteLine("count={0} {1}:{2}.{3}", count, stopWatch.Elapsed.Minutes, stopWatch.Elapsed.Seconds, stopWatch.Elapsed.Milliseconds);
            Console.WriteLine("Complete: Test on a Subset of Generic Dictionary collection.\n");

            GC.Collect();
            GC.WaitForPendingFinalizers();

            return stopWatch.Elapsed;
        }
    }
}
