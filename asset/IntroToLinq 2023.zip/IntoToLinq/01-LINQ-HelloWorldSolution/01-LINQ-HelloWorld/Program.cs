﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace LINQ_HelloWorld
{
    class Program
    {
        /// <summary>
        /// Illustrates LINQ statement syntax
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            ConsoleKeyInfo menuChoice = DisplayMenuAndGetUserSelection();
            do
            {
                switch (menuChoice.Key)
                {
                    case ConsoleKey.D1:
                        SimpleLINQExample();
                        break;
                    case ConsoleKey.D2:
                        ConditionalSortedQuery();
                        break;
                }
                menuChoice = DisplayMenuAndGetUserSelection();
            } while (menuChoice.Key != ConsoleKey.Escape);
        }

        /// <summary>
        /// Display menu and get user's choice
        /// </summary>
        /// <returns>The user's menu choice</returns>
        private static ConsoleKeyInfo DisplayMenuAndGetUserSelection()
        {
            Console.Clear();
            Console.WriteLine("Choose 1-2 or ESC to exit program");
            Console.WriteLine("1 - SimpleLINQExample()");
            Console.WriteLine("2 - ConditionalSortedQuery()");
            Console.WriteLine("ESC - Exit Program");
            return Console.ReadKey();
        }

        /// <summary>
        /// Illustrates a simple LINQ expression with a conditional statement
        /// </summary>
        private static void SimpleLINQExample()
        {
            Console.Clear();
            Console.WriteLine("Illustrates a simple LINQ expression with a conditional statement\n");

            int[] myInts = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            IEnumerable<int> intsLessThanSix = from s in myInts
                                               where s < 6 select s;

            foreach (int item in intsLessThanSix)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

        }

        /// <summary>
        /// Illustrates a conditional query that sorts the results
        /// </summary>
        private static void ConditionalSortedQuery()
        {
            Console.Clear();
            Console.WriteLine("Illustrates a conditional query that sorts the results\n");

            string[] myArray = { "2-Isn't ", "1-World!\n", "0-Hello ", "4-Cool! ", "3-LINQ ", "XXXX" };

            var sortedArray = from s in myArray
                              where s.EndsWith(" ") || s.EndsWith("\n")
                              orderby s ascending
                              select s.Substring(2);

            foreach (string item in sortedArray)
            {
                Console.Write(item);
            }

            Console.WriteLine("\n\nPress enter to continue...");
            Console.ReadLine();
        }
    }
}
