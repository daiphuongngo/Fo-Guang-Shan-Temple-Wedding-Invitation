﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ_ExtensionMethods
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleKeyInfo menuChoice = DisplayMenuAndGetUserSelection();
            do
            {
                switch (menuChoice.Key)
                {
                    case ConsoleKey.D1:
                        UsingExtensionMethodsDirectly();
                        break;
                    case ConsoleKey.D2:
                        SimpleLINQExampleInvokingExtensionMethod();
                        break;
                }
                menuChoice = DisplayMenuAndGetUserSelection();
            } while (menuChoice.Key != ConsoleKey.Escape);
        }

        /// <summary>
        /// Display menu and get user's choice
        /// </summary>
        /// <returns>The user's menu choice</returns>
        private static ConsoleKeyInfo DisplayMenuAndGetUserSelection()
        {
            Console.Clear();
            Console.WriteLine("Choose 1-2 or ESC to exit program");
            Console.WriteLine("1 - UsingExtensionMethodsDirectly()");
            Console.WriteLine("2 - SimpleLINQExampleInvokingExtensionMethod()");
            Console.WriteLine("ESC - Exit Program");
            return Console.ReadKey();
        }


        /// <summary>
        /// Illustrates using LINQ provided extension methods directly
        /// </summary>
        static void UsingExtensionMethodsDirectly()
        {
            Console.Clear();
            Console.WriteLine("Illustrates using LINQ provided extension methods directly\n");

            int[] myInts = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            Console.WriteLine("  Example sum of { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }");

            int sumOfInts = myInts.Sum();

            Console.WriteLine("  Sum of ints: {0}", sumOfInts);

            Console.WriteLine("\n  Example sum of { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }, doubling each value");

            // Terse syntax using anonymous method "i * 2" defined in line.
            int sumOfDoubleIntsA = myInts.Sum(i => i * 2);

            // Equivalent syntax but calling a method rather than embedding method
            int sumOfDoubleIntsB = myInts.Sum(i => { return DoubleMe(myInts,i); });

            Console.WriteLine("  Sum of doubling each int in myInts: \n\tsumOfDoubleIntsA: {0}\n\tsumOfDoubleIntsB: {0}", sumOfDoubleIntsB);

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

        }

        /// <summary>
        /// Doubles the value item) passed in.
        /// </summary>
        /// <typeparam name="TSource">The type of the source.</typeparam>
        /// <param name="source">The source of the values coming from item</param>
        /// <param name="item">The item value to operate on.</param>
        /// <returns></returns>
        static int DoubleMe<TSource>(TSource source, int item)
        {
            return item * 2;
        }

        /// <summary>
        /// Illustrates a use of extension methods in an LINQ expression
        /// </summary>
        private static void SimpleLINQExampleInvokingExtensionMethod()
        {
            Console.Clear();
            Console.WriteLine("Illustrates a use of extension methods in an LINQ expression \n");

            int[] myInts = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            Console.WriteLine("  Example sum of { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 } but only values less than 6");

            int sumOfInts = (from s in myInts where s < 6 select s).Sum();

            Console.WriteLine("  Sum of ints less than six: {0}", sumOfInts);

            Console.WriteLine("\n  Example sum of { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 } doubling each value, but only values less than 6");

            IEnumerable<int> x = from s in myInts where s < 3 select s;

            int sumOfDoubleInts = (from s in myInts where s < 6 select s).Sum(i => i * 2);

            Console.WriteLine("  Sum of doubling ints less than six: {0}", sumOfDoubleInts);

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

        }

    }
}
