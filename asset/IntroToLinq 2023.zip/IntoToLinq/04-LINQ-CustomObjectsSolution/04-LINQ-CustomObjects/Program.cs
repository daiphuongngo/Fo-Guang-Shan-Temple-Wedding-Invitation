﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ_CustomObjects
{

    public class Person
    {
        /// <summary>
        /// All defined occupations
        /// </summary>
        public enum Occupations
        {
            Scientist,
            SoftwareEngineer,
            Astronaut
        }

        public string Name { get; set; }
        public int Age { get; set; }
        public string PhoneNumber { get; set; }
        public Occupations Occupation { get; set; }

        /// <summary>
        /// Returns a <see cref="System.String"/> a nicely formatted string that represents the person.
        /// </summary>
        /// <returns>
        /// A <see cref="System.String"/> A nicely formatted string that represents the person.
        /// </returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
             
            sb.Append(string.Format("  Name       = {0}\n",Name));
            sb.Append(string.Format("  Age        = {0}\n",Age));
            sb.Append(string.Format("  Phone      = {0}\n",PhoneNumber));
            sb.Append(string.Format("  Occupation = {0}\n\n",Occupation));

            return sb.ToString();
        }
    }

    class Program
    {
        /// <summary>
        /// Illustrates working with custom objects and LINQ Expressions
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {

            ConsoleKeyInfo menuChoice = DisplayMenuAndGetUserSelection();
            do
            {
                switch (menuChoice.Key)
                {
                    case ConsoleKey.D1:
                        QueryingCollectionOfPeople();
                        break;
                    case ConsoleKey.D2:
                        SortingAndQueryingCollectionOfPeople();
                        break;
                    case ConsoleKey.D3:
                        QueryingNonGenericCollectionOfPeople();
                        break;
                }
                menuChoice = DisplayMenuAndGetUserSelection();
            } while (menuChoice.Key != ConsoleKey.Escape);
        }

        /// <summary>
        /// Display menu and get user's choice
        /// </summary>
        /// <returns>The user's menu choice</returns>
        private static ConsoleKeyInfo DisplayMenuAndGetUserSelection()
        {
            Console.Clear();
            Console.WriteLine("Choose 1-3 or ESC to exit program");
            Console.WriteLine("1 - QueryingCollectionOfPeople()");
            Console.WriteLine("2 - SortingAndQueryingCollectionOfPeople()");
            Console.WriteLine("3 - QueryingNonGenericCollectionOfPeople()");
            Console.WriteLine("ESC - Exit Program");
            return Console.ReadKey();
        }


        /// <summary>
        /// Illustrates querying a collection of people, constrained using the where clause
        /// </summary>
        static void QueryingCollectionOfPeople()
        {
            Console.Clear();
            Console.WriteLine("Illustrates querying a collection of people, constrained using the where clause\n");

            List<Person> myPeople = new List<Person>()
            {
                new Person {Name = "Bob", Age = 32, PhoneNumber = "555-1212", Occupation = Person.Occupations.Scientist},
                new Person {Name = "Sue", Age = 25, PhoneNumber = "555-1313", Occupation = Person.Occupations.SoftwareEngineer},
                new Person {Name = "Beth",Age = 40, PhoneNumber = "555-3232", Occupation = Person.Occupations.Astronaut},
                new Person {Name = "Jack",Age = 54, PhoneNumber = "555-2222", Occupation = Person.Occupations.SoftwareEngineer}
            };

            IEnumerable<Person> peopleOlderThanTwentyFive = from s in myPeople
                                                            where s.Age > 25 
                                                            select s;

            Console.WriteLine("Display people older than 25\n");
            foreach (Person thePerson in peopleOlderThanTwentyFive)
            {
                Console.WriteLine(thePerson);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

        }

        /// <summary>
        /// Illustrates sorting and querying a collection of people
        /// </summary>
        static void SortingAndQueryingCollectionOfPeople()
        {
            Console.Clear();
            Console.WriteLine("Illustrates sorting and querying a collection of people\n");

            List<Person> myPeople = new List<Person>()
            {
                new Person {Name = "Bob", Age = 32, PhoneNumber = "555-1212", Occupation = Person.Occupations.Scientist},
                new Person {Name = "Sue", Age = 25, PhoneNumber = "555-1313", Occupation = Person.Occupations.SoftwareEngineer},
                new Person {Name = "Beth",Age = 40, PhoneNumber = "555-3232", Occupation = Person.Occupations.Astronaut},
                new Person {Name = "Jack",Age = 54, PhoneNumber = "555-2222", Occupation = Person.Occupations.SoftwareEngineer}
            };

            IEnumerable<Person> sortedPeople = from s in myPeople 
                                               orderby s.Age descending 
                                               where s.Age > 25 
                                               select s;

            Console.WriteLine("Display people older than 25 sorted oldest to youngest.\n");
            foreach (Person thePerson in sortedPeople)
            {
                Console.WriteLine(thePerson);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

        }

        /// <summary>
        /// Illustrates querying a non generic collection of people, constrained using the where clause
        /// </summary>
        static void QueryingNonGenericCollectionOfPeople()
        {
            Console.Clear();
            Console.WriteLine("Illustrates querying a non generic collection of people, constrained using the where clause\n");

            System.Collections.ArrayList myPeople = new System.Collections.ArrayList()            
            {
                new Person {Name = "Bob", Age = 32, PhoneNumber = "555-1212", Occupation = Person.Occupations.Scientist},
                new Person {Name = "Sue", Age = 25, PhoneNumber = "555-1313", Occupation = Person.Occupations.SoftwareEngineer},
                new Person {Name = "Beth",Age = 40, PhoneNumber = "555-3232", Occupation = Person.Occupations.Astronaut},
                new Person {Name = "Jack",Age = 54, PhoneNumber = "555-2222", Occupation = Person.Occupations.SoftwareEngineer}
                
                // Uncomment to illustrate filtering by Person...
                ,
                "Hello World",
                1,
                2,
                3
            };

            Console.WriteLine("All elements in array list\n" );
            foreach (var item in myPeople)
            {
                Console.WriteLine("  " + item);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();
            
            // Get only Person objects out of the array list  (Does not make a copy, still connected...)
            IEnumerable<Person> myPeopleEnum = myPeople.OfType<Person>();

            // Query for people who's age is greater than 25
            IEnumerable<Person> peopleOlderThanTwentyFiveA = from s in myPeopleEnum 
                                                             where s.Age > 25 
                                                             select s;

            Console.WriteLine("Display people older than 25\n");
            foreach (Person thePerson in peopleOlderThanTwentyFiveA)
            {
                Console.WriteLine(thePerson);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

            // Query for people who's age is greater than 25 filtering only Person objects out of the array
            // Again myPeople.OfType<Person>() does not make a copy, still connected to the original data source...
            IEnumerable<Person> peopleOlderThanTwentyFiveB = from s in myPeople.OfType<Person>() 
                                                             where s.Age > 25 
                                                             select s;

            Console.WriteLine("\nDisplay people older than 25, before change to data...\n");
            foreach (var thePerson in peopleOlderThanTwentyFiveB)
            {
                Console.WriteLine(thePerson);
            }


            // Query for people who's age is greater than 25 filtering only Person objects out of the array who are Astronauts
            // Again myPeople.OfType<Person>() does not make a copy, still connected to the original data source...
            IEnumerable<Person> peopleOlderThanTwentyFiveC = from s in myPeople.OfType<Person>() 
                                                             where s.Age > 25 && s.Occupation == Person.Occupations.Astronaut 
                                                             select s;
            // Make a change to show still connected
            ((Person)myPeople[2]).Name = ((Person)myPeople[2]).Name + " " + DateTime.Now.ToShortTimeString();

            Console.WriteLine("\nDisplay people older than 25 who are Astronauts after changing data..\n");
            foreach (Person thePerson in peopleOlderThanTwentyFiveC)
            {
                #region Really Prove It Demo
                // Really its just a reference even doing the change here works!
                //((Person)myPeople[2]).Name = ((Person)myPeople[2]).Name + " " + DateTime.Now.ToShortTimeString();
                #endregion

                Console.WriteLine(thePerson);
            }

            Console.WriteLine("\nPress enter to continue...");
            Console.ReadLine();

           

        }



    }
}
