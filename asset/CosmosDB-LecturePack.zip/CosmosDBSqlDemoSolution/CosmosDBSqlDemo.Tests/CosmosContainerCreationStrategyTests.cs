using System.Net;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Moq;

namespace CosmosDBSqlDemo.Tests;

public class CosmosContainerCreationStrategyTests
{
    [Fact]
    public void CreateContainerIfNotExists_UsesServerlessPath_WhenNoThroughputCreateSucceeds()
    {
        CosmosContainerCreationStrategy strategy = new();
        ContainerProperties containerProperties = new("PeopleCollection", "/companyId");
        Mock<Container> expectedContainer = new();
        Mock<ILogger> logger = new();
        bool throughputPathCalled = false;

        Container container = strategy.CreateContainerIfNotExists(
            containerProperties,
            offerThroughput: 800,
            logger: logger.Object,
            createWithoutThroughput: _ => expectedContainer.Object,
            createWithThroughput: (_, _) =>
            {
                throughputPathCalled = true;
                return new Mock<Container>().Object;
            });

        Assert.Same(expectedContainer.Object, container);
        Assert.False(throughputPathCalled);
        Assert.Contains(logger.Invocations, invocation => HasLogMessage(invocation, LogLevel.Information, "Attempting container creation without throughput"));
        Assert.Contains(logger.Invocations, invocation => HasLogMessage(invocation, LogLevel.Information, "Using no-throughput container creation strategy"));
    }

    [Fact]
    public void CreateContainerIfNotExists_RetriesWithConfiguredThroughput_WhenProvisionedThroughputIsRequired()
    {
        CosmosContainerCreationStrategy strategy = new();
        ContainerProperties containerProperties = new("PeopleCollection", "/companyId");
        Mock<Container> fallbackContainer = new();
        Mock<ILogger> logger = new();
        int? throughputUsed = null;

        Container container = strategy.CreateContainerIfNotExists(
            containerProperties,
            offerThroughput: 1200,
            logger: logger.Object,
            createWithoutThroughput: _ => throw CreateCosmosException(
                HttpStatusCode.BadRequest,
                "The throughput is required for non-serverless accounts."),
            createWithThroughput: (_, throughput) =>
            {
                throughputUsed = throughput;
                return fallbackContainer.Object;
            });

        Assert.Same(fallbackContainer.Object, container);
        Assert.Equal(1200, throughputUsed);
        Assert.Contains(logger.Invocations, invocation => HasLogMessage(invocation, LogLevel.Information, "Attempting container creation without throughput"));
        Assert.Contains(logger.Invocations, invocation => HasLogMessage(invocation, LogLevel.Information, "falling back to provisioned throughput"));
        Assert.Contains(logger.Invocations, invocation => HasLogMessage(invocation, LogLevel.Information, "Attempting container creation with throughput 1200"));
        Assert.Contains(logger.Invocations, invocation => HasLogMessage(invocation, LogLevel.Information, "Using provisioned-throughput container creation strategy"));
    }

    [Fact]
    public void CreateContainerIfNotExists_RethrowsUnexpectedCosmosException()
    {
        CosmosContainerCreationStrategy strategy = new();
        ContainerProperties containerProperties = new("PeopleCollection", "/companyId");
        CosmosException expectedException = CreateCosmosException(
            HttpStatusCode.BadRequest,
            "The partition key path is invalid.");
        Mock<ILogger> logger = new();
        bool throughputPathCalled = false;

        CosmosException actualException = Assert.Throws<CosmosException>(() => strategy.CreateContainerIfNotExists(
            containerProperties,
            offerThroughput: 1200,
            logger: logger.Object,
            createWithoutThroughput: _ => throw expectedException,
            createWithThroughput: (_, _) =>
            {
                throughputPathCalled = true;
                return new Mock<Container>().Object;
            }));

        Assert.Same(expectedException, actualException);
        Assert.False(throughputPathCalled);
    }

    [Fact]
    public void IsProvisionedThroughputRequired_ReturnsFalse_WhenBadRequestIsNotAboutThroughput()
    {
        CosmosContainerCreationStrategy strategy = new();
        CosmosException exception = CreateCosmosException(
            HttpStatusCode.BadRequest,
            "The indexing policy is invalid.");

        bool isProvisionedAccount = strategy.IsProvisionedThroughputRequired(exception);

        Assert.False(isProvisionedAccount);
    }

    private static CosmosException CreateCosmosException(HttpStatusCode statusCode, string message)
    {
        return new CosmosException(message, statusCode, subStatusCode: 0, activityId: Guid.NewGuid().ToString(), requestCharge: 0);
    }

    private static bool HasLogMessage(IInvocation invocation, LogLevel expectedLevel, string expectedMessageFragment)
    {
        if (invocation.Method.Name != nameof(ILogger.Log))
        {
            return false;
        }

        if (invocation.Arguments.Count < 3 || invocation.Arguments[0] is not LogLevel actualLevel)
        {
            return false;
        }

        return actualLevel == expectedLevel
            && invocation.Arguments[2]?.ToString()?.Contains(expectedMessageFragment, StringComparison.Ordinal) == true;
    }
}
