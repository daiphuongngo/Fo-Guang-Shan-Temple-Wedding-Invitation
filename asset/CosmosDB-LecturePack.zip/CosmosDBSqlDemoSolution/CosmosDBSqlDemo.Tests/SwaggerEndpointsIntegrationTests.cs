using System.Collections.Concurrent;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Logging;

namespace CosmosDBSqlDemo.Tests;

public class SwaggerEndpointsIntegrationTests
{
    [Fact]
    public async Task SwaggerUiAndDocument_LoadWithoutErrors()
    {
        TestLogCollector collector = new();

        await using WebApplicationFactory<Program> factory = new WebApplicationFactory<Program>()
            .WithWebHostBuilder(builder =>
            {
                builder.ConfigureLogging(logging =>
                {
                    logging.ClearProviders();
                    logging.AddProvider(new TestLoggerProvider(collector));
                    logging.SetMinimumLevel(LogLevel.Trace);
                });
            });

        using HttpClient client = factory.CreateClient(new WebApplicationFactoryClientOptions
        {
            BaseAddress = new Uri("https://localhost"),
            AllowAutoRedirect = true
        });

        HttpResponseMessage swaggerUiResponse = await client.GetAsync("/");
        string swaggerUiContent = await swaggerUiResponse.Content.ReadAsStringAsync();

        swaggerUiResponse.EnsureSuccessStatusCode();
        Assert.Contains("Swagger UI", swaggerUiContent, StringComparison.Ordinal);

        HttpResponseMessage swaggerJsonResponse = await client.GetAsync("/swagger/v1/swagger.json");
        string swaggerJsonContent = await swaggerJsonResponse.Content.ReadAsStringAsync();

        swaggerJsonResponse.EnsureSuccessStatusCode();
        Assert.Contains("\"openapi\"", swaggerJsonContent, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("Cosmos DB SQL API Demo", swaggerJsonContent, StringComparison.Ordinal);
        Assert.DoesNotContain(collector.Entries, entry => entry.LogLevel >= LogLevel.Error);
    }

    private sealed class TestLoggerProvider(TestLogCollector collector) : ILoggerProvider
    {
        public ILogger CreateLogger(string categoryName)
        {
            return new TestLogger(categoryName, collector);
        }

        public void Dispose()
        {
        }
    }

    private sealed class TestLogger(string categoryName, TestLogCollector collector) : ILogger
    {
        public IDisposable BeginScope<TState>(TState state) where TState : notnull
        {
            return NullScope.Instance;
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return true;
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
        {
            collector.Entries.Enqueue(new TestLogEntry(
                LogLevel: logLevel,
                CategoryName: categoryName,
                Message: formatter(state, exception),
                Exception: exception));
        }
    }

    private sealed class TestLogCollector
    {
        public ConcurrentQueue<TestLogEntry> Entries { get; } = new();
    }

    private sealed record TestLogEntry(LogLevel LogLevel, string CategoryName, string Message, Exception? Exception);

    private sealed class NullScope : IDisposable
    {
        public static NullScope Instance { get; } = new();

        public void Dispose()
        {
        }
    }
}
