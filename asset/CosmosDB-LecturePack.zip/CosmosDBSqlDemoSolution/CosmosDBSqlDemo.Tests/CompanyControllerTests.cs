using System.Net;
using CosmosDBSqlDemo.Controllers;
using CosmosDBSqlDemo.DataObjects;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Moq;

namespace CosmosDBSqlDemo.Tests;

public class CompanyControllerTests
{
    [Fact]
    public void RuntimeActivation_HasSingleApplicableConstructor()
    {
        Exception? exception = Record.Exception(() => ActivatorUtilities.CreateFactory(typeof(CompanyController), Type.EmptyTypes));

        Assert.Null(exception);
    }

    [Fact]
    public async Task Get_ReturnsDistinctSortedCompaniesWithUniquePersonTypes()
    {
        List<Person> firstPageItems =
        [
            new() { CompanyId = "Contoso" },
            new() { CompanyId = "Contoso" },
            new() { CompanyId = "Fabrikam" }
        ];
        SetPersonType(firstPageItems[0], "Person");
        SetPersonType(firstPageItems[1], "TwitterPerson");
        SetPersonType(firstPageItems[2], "FacebookPerson");

        List<Person> secondPageItems =
        [
            new() { CompanyId = "Contoso" },
            new() { CompanyId = "AdventureWorks" },
            new() { CompanyId = "AdventureWorks" },
            new() { CompanyId = "", }
        ];
        SetPersonType(secondPageItems[0], "Person");
        SetPersonType(secondPageItems[1], "TwitterPerson");
        SetPersonType(secondPageItems[2], "FacebookPerson");
        SetPersonType(secondPageItems[3], "IgnoredPersonType");

        Mock<Container> container = new();
        Mock<FeedIterator<Person>> iterator = new();
        Mock<FeedResponse<Person>> firstPageResponse = CreateFeedResponse(firstPageItems, requestCharge: 3.5);
        Mock<FeedResponse<Person>> secondPageResponse = CreateFeedResponse(secondPageItems, requestCharge: 2.1);
        CompanyController controller = CreateController(container.Object);

        iterator.SetupSequence(x => x.HasMoreResults)
            .Returns(true)
            .Returns(true)
            .Returns(false);
        iterator.SetupSequence(x => x.ReadNextAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(firstPageResponse.Object)
            .ReturnsAsync(secondPageResponse.Object);
        container.Setup(x => x.GetItemQueryIterator<Person>(
                It.Is<QueryDefinition>(query => query.QueryText == "SELECT p.companyId, p.personType FROM p"),
                It.IsAny<string?>(),
                It.IsAny<QueryRequestOptions?>()))
            .Returns(iterator.Object);

        IActionResult actionResult = await controller.Get();

        ObjectResult objectResult = Assert.IsType<ObjectResult>(actionResult);
        List<Company> companies = Assert.IsType<List<Company>>(objectResult.Value);
        Assert.Collection(
            companies,
            company =>
            {
                Assert.Equal("AdventureWorks", company.CompanyId);
                Assert.Equal(["FacebookPerson", "TwitterPerson"], company.PersonTypes);
            },
            company =>
            {
                Assert.Equal("Contoso", company.CompanyId);
                Assert.Equal(["Person", "TwitterPerson"], company.PersonTypes);
            },
            company =>
            {
                Assert.Equal("Fabrikam", company.CompanyId);
                Assert.Equal(["FacebookPerson"], company.PersonTypes);
            });
        container.VerifyAll();
    }

    [Fact]
    public async Task Get_ReturnsCosmosStatusCode_WhenQueryFails()
    {
        Mock<Container> container = new();
        Mock<FeedIterator<Person>> iterator = new();
        CompanyController controller = CreateController(container.Object);

        iterator.SetupSequence(x => x.HasMoreResults)
            .Returns(true);
        iterator.Setup(x => x.ReadNextAsync(It.IsAny<CancellationToken>()))
            .ThrowsAsync(new CosmosException("Boom", HttpStatusCode.BadGateway, 0, Guid.NewGuid().ToString(), 0));
        container.Setup(x => x.GetItemQueryIterator<Person>(
                It.IsAny<QueryDefinition>(),
                It.IsAny<string?>(),
                It.IsAny<QueryRequestOptions?>()))
            .Returns(iterator.Object);

        IActionResult actionResult = await controller.Get();

        ObjectResult objectResult = Assert.IsType<ObjectResult>(actionResult);
        Assert.Equal((int)HttpStatusCode.BadGateway, objectResult.StatusCode);
        Assert.Equal("Failed to get the company ids", objectResult.Value);
    }

    private static CompanyController CreateController(Container container)
    {
        CosmosDBSettings cosmosDbSettings = new()
        {
            CollectionName = "PeopleCollection",
            PartitionKeyName = "companyId"
        };

        return new CompanyController(
            new Mock<ILogger<CompanyController>>().Object,
            cosmosDbSettings,
            container);
    }

    private static Mock<FeedResponse<Person>> CreateFeedResponse(IReadOnlyList<Person> items, double requestCharge)
    {
        Mock<FeedResponse<Person>> response = new();
        response.Setup(x => x.RequestCharge).Returns(requestCharge);
        response.Setup(x => x.Diagnostics).Returns((CosmosDiagnostics?)null!);
        response.As<IEnumerable<Person>>()
            .Setup(x => x.GetEnumerator())
            .Returns(() => items.ToList().GetEnumerator());

        return response;
    }

    private static void SetPersonType(Person person, string personType)
    {
        typeof(Person)
            .GetProperty(nameof(Person.PersonType))!
            .SetValue(person, personType);
    }
}
