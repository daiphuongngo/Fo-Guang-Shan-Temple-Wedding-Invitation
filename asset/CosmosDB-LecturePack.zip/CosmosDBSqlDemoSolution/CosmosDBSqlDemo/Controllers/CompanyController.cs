using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using CosmosDBSqlDemo.DataObjects;

namespace CosmosDBSqlDemo.Controllers
{
    /// <summary>
    /// Provides access to company identifiers in the people collection.
    /// </summary>
    [Produces("application/json")]
    public class CompanyController : PersonBaseController<CompanyController>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="cosmosDBSettings">The Cosmos DB settings.</param>
        public CompanyController(ILogger<CompanyController> logger,
                                 CosmosDBSettings cosmosDBSettings) : base(logger, cosmosDBSettings)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyController"/> class for tests that provide a container directly.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="cosmosDBSettings">The Cosmos DB settings.</param>
        /// <param name="containerInstance">The container instance.</param>
        internal CompanyController(ILogger<CompanyController> logger,
                                   CosmosDBSettings cosmosDBSettings,
                                   Container containerInstance) : base(logger, cosmosDBSettings, containerInstance)
        {
        }

        /// <summary>
        /// Gets the distinct company identifiers stored in the people collection with their unique person types.
        /// </summary>
        /// <returns>The distinct company identifiers and their unique person types.</returns>
        [ProducesResponseType(typeof(IEnumerable<Company>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Route("/api/v1/Company")]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            List<Person> companyPeople = new();
            QueryDefinition query = new QueryDefinition("SELECT p.companyId, p.personType FROM p");
            FeedIterator<Person> resultSetIterator = ContainerInstance.GetItemQueryIterator<Person>(query);

            try
            {
                while (resultSetIterator.HasMoreResults)
                {
                    FeedResponse<Person> response = await resultSetIterator.ReadNextAsync();

                    foreach (Person person in response)
                    {
                        if (!string.IsNullOrWhiteSpace(person.CompanyId))
                        {
                            companyPeople.Add(person);
                        }
                    }

                    LogRequestCharge(response.RequestCharge);
                    LogFullDiagnostics(response.Diagnostics);
                }

                List<Company> companies = companyPeople
                    .GroupBy(person => person.CompanyId, StringComparer.Ordinal)
                    .Select(companyGrouping => new Company
                    {
                        CompanyId = companyGrouping.Key,
                        PersonTypes = companyGrouping
                            .Select(person => person.PersonType)
                            .Where(personType => !string.IsNullOrWhiteSpace(personType))
                            .Distinct(StringComparer.Ordinal)
                            .OrderBy(personType => personType, StringComparer.Ordinal)
                            .ToList()
                    })
                    .OrderBy(company => company.CompanyId, StringComparer.Ordinal)
                    .ToList();

                return new ObjectResult(companies);
            }
            catch (CosmosException cex)
            {
                System.Diagnostics.Trace.TraceWarning("Failed to get the company ids {0}", cex.Message);
                return StatusCode((int)cex.StatusCode, "Failed to get the company ids");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceInformation("Failed to get the company ids {0}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, $"Exception {ex.Message}");
            }
        }
    }
}
