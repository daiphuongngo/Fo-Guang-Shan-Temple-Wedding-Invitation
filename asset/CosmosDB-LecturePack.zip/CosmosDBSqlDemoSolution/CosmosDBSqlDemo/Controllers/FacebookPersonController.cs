﻿// CSCI-E94 Fundamendals of cloud computing demo template with Microsoft Azure
// Joseph Ficara (c) 2018 - 2021
using System;
using System.Collections;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Linq;
using CosmosDBSqlDemo.DataObjects;
using System.Threading.Tasks;
using System.Reflection.Metadata;
using Microsoft.Azure.Cosmos;

namespace CosmosDBSqlDemo.Controllers
{
    /// <summary>
    /// Provides access to the facebookperson resource
    /// </summary>
    [Produces("application/json")]
    public class FacebookPersonController : PersonBaseController<FacebookPersonController>
    {
        private const string GetFacebookPersonByIdRouteName = "GetFacebookPersonByIdRouteName";

        /// <summary>
        /// Initializes a new instance of the <see cref="FacebookPersonController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>        
        /// <param name="cosmosDBSettings">The cosmos database settings.</param>
        public FacebookPersonController(ILogger<FacebookPersonController> logger,                                   
                                   CosmosDBSettings cosmosDBSettings) : base(logger, cosmosDBSettings)
        {
        }

        /// <summary>
        /// Gets all of the facebook people in the collection
        /// </summary>
        /// <param name="companyId">The company identifier.</param>
        /// <returns>List of FacebookPersons.</returns>
        [ProducesResponseType(typeof(IEnumerable<object>), StatusCodes.Status200OK)]
        [Route("/api/v1/{companyId}/FacebookPerson")]
        [HttpGet]
        public async Task<IActionResult> Get(string companyId)
        {
            List<FacebookPerson> facebookPeopleList = new List<FacebookPerson>();

            // Define a SQL query to return all of the people
            QueryDefinition query = new QueryDefinition($"SELECT * FROM {CosmosDBSettings.CollectionName} p WHERE p.personType = @personType")                
                .WithParameter("@personType",typeof(FacebookPerson).Name);

            FeedIterator<FacebookPerson> resultSetIterator = ContainerInstance?.GetItemQueryIterator<FacebookPerson>(query, requestOptions: new QueryRequestOptions() { PartitionKey = new PartitionKey(companyId) });

            // Note: This does not scale, the API should expose querying for additional
            // records and not attempt to get them all at once.
            while (resultSetIterator.HasMoreResults)
            {
                FeedResponse<FacebookPerson> response = await resultSetIterator.ReadNextAsync();

                foreach (FacebookPerson facebookPerson in response)
                {
                    facebookPeopleList.Add(facebookPerson);
                }

                LogRequestCharge(response.RequestCharge);

                LogFullDiagnostics(response.Diagnostics);                
            }

            // Return the result set of people
            return new ObjectResult(facebookPeopleList);

        }


        /// <summary>
        /// Gets facebook person specified by the id
        /// </summary>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="facebookId">The identifier.</param>
        /// <returns>FacebookPerson</returns>
        [ProducesResponseType(typeof(FacebookPerson), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Route("/api/v1/{companyId}/FacebookPerson/{facebookId}", Name = GetFacebookPersonByIdRouteName)]
        [HttpGet]
        public async Task<IActionResult> Get(string companyId, string facebookId)
        {

            List<FacebookPerson> facebookPeopleList = new List<FacebookPerson>();

            // Define a SQL query to return all of the people
            QueryDefinition query = new QueryDefinition(
                $"SELECT p.facebookId, p.facebookPosts, p.id, p.companyId, p.name, " +
                            $"p.age, p.personType, p.memberSince, p.memberSinceTimeStamp, " +
                            $"p.metadata " +
                            $"FROM {CosmosDBSettings.CollectionName} p " +
                            $"WHERE p.personType = @personType AND p.facebookId = @facebookId AND p.companyId = @companyId")
                .WithParameter("@personType", typeof(FacebookPerson).Name)
                .WithParameter("@facebookId", facebookId)
                .WithParameter("@companyId", companyId);

            FeedIterator<FacebookPerson> resultSetIterator = ContainerInstance.GetItemQueryIterator<FacebookPerson>(query, requestOptions: new QueryRequestOptions() { PartitionKey = new PartitionKey(companyId) });

            // Note: There should be only a single result
            while (resultSetIterator.HasMoreResults)
            {
                FeedResponse<FacebookPerson> response = await resultSetIterator.ReadNextAsync();

                foreach (FacebookPerson facebookPerson in response)
                {
                    facebookPeopleList.Add(facebookPerson);
                }

                LogRequestCharge(response.RequestCharge);

                LogFullDiagnostics(response.Diagnostics);
            }

            if (facebookPeopleList.Count == 1)
            {
                return new ObjectResult(facebookPeopleList[0]);
            }

            // Let the caller know the resource for the ID could not be found.
            return NotFound($"Person {facebookId} not found.");
        }

        /// <summary>
        /// Creates specified facebook person.
        /// </summary>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="facebookPersonCreate">The facebook person data to create.</param>
        /// <returns>FacebookPerson</returns>
        [ProducesResponseType(typeof(FacebookPerson), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Route("/api/v1/{companyId}/FacebookPerson")]
        [HttpPost]
        public async Task<IActionResult> Post(string companyId,[FromBody]FacebookPersonCreate facebookPersonCreate)
        {
            ItemResponse<FacebookPerson> result;

            try
            {
                FacebookPerson facebookPerson = new FacebookPerson(facebookPersonCreate);                

                // Assign the Id, this is RESTfull because we are using POST
                facebookPerson.CompanyId = companyId;

                // Ensuring that the companyId is correctly set.
                facebookPerson.Id = Guid.NewGuid().ToString();
                
                result = await ContainerInstance.CreateItemAsync(facebookPerson, new PartitionKey(companyId));

                LogRequestCharge(result.RequestCharge);

                LogFullDiagnostics(result.Diagnostics);
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to create the Facebook person {message}", ex.Message);

                return StatusCode(StatusCodes.Status500InternalServerError, $"Exception {ex.Message}");
            }

            return CreatedAtRoute(GetFacebookPersonByIdRouteName, new { facebookId = result.Resource.Id, companyId = companyId }, result);
        }
    }


}
