﻿// CSCI-E94 Fundamendals of cloud computing demo template with Microsoft Azure
// Joseph Ficara (c) 2018 - 2021
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using CosmosDBSqlDemo.DataObjects;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos;

namespace CosmosDBSqlDemo.Controllers
{
    /// <summary>
    /// Provides access to the twitterperson resource
    /// </summary>
    [Produces("application/json")]
    public class TwitterPersonController : PersonBaseController<TwitterPersonController>
    {
        private const string GetTwitterPersonByIdRouteName = "GetTwitterPersonByIdRouteName";

        /// <summary>
        /// Initializes a new instance of the <see cref="TwitterPersonController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>        
        /// <param name="cosmosDBSettings">The cosmos database settings.</param>
        public TwitterPersonController(ILogger<TwitterPersonController> logger,                                   
                                   CosmosDBSettings cosmosDBSettings) : base(logger,  cosmosDBSettings)
        {
        }

        /// <summary>
        /// Gets all of the twitter people in the collection
        /// </summary>
        /// <returns>List of TwitterPersons.</returns>
        [ProducesResponseType(typeof(IEnumerable<object>), StatusCodes.Status200OK)]
        [Route("/api/v1/{companyId}/TwitterPerson")]
        [HttpGet]
        public async Task<IActionResult> Get(string companyId)
        {
            List<TwitterPerson> twitterPeopleList = new List<TwitterPerson>();

            // Define a SQL query to return all of the people
            QueryDefinition query = new QueryDefinition($"SELECT * FROM {CosmosDBSettings.CollectionName} p WHERE p.personType = @personType")                
                .WithParameter("@personType", typeof(TwitterPerson).Name);

            FeedIterator<TwitterPerson> resultSetIterator = ContainerInstance.GetItemQueryIterator<TwitterPerson>(query, requestOptions: new QueryRequestOptions() { PartitionKey = new PartitionKey(companyId) });

            // Note: This does not scale, the API should expose querying for additional
            // records and not attempt to get them all at once.
            while (resultSetIterator.HasMoreResults)
            {
                FeedResponse<TwitterPerson> response = await resultSetIterator.ReadNextAsync();

                foreach (TwitterPerson twitterPerson in response)
                {
                    twitterPeopleList.Add(twitterPerson);
                }

                LogRequestCharge(response.RequestCharge);

                LogFullDiagnostics(response.Diagnostics);
            }

            // Return the result set of people
            return new ObjectResult(twitterPeopleList);


        }


        /// <summary>
        /// Gets twitter person specified by the twitterId
        /// </summary>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="twitterId">The identifier.</param>
        /// <returns>TwitterPerson</returns>
        [ProducesResponseType(typeof(TwitterPerson), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Route("/api/v1/{companyId}/TwitterPerson/{twitterId}", Name = GetTwitterPersonByIdRouteName)]
        [HttpGet]
        public async Task<IActionResult> Get(string companyId, string twitterId)
        {
            List<TwitterPerson> twitterPeopleList = new List<TwitterPerson>();

            // Define a SQL query to return all of the people
            QueryDefinition query = new QueryDefinition($"SELECT * FROM {CosmosDBSettings.CollectionName} p " +
                $"WHERE p.personType = @personType AND p.twitterId = @twitterId AND p.companyId = @companyId")
                .WithParameter("@personType", typeof(TwitterPerson).Name)
                .WithParameter("@twitterId", twitterId)
                .WithParameter("@companyId", companyId);

            FeedIterator<TwitterPerson> resultSetIterator = ContainerInstance.GetItemQueryIterator<TwitterPerson>(query, requestOptions: new QueryRequestOptions() { PartitionKey = new PartitionKey(companyId) });

            // Note: This does not scale, the API should expose querying for additional
            // records and not attempt to get them all at once.
            while (resultSetIterator.HasMoreResults)
            {
                FeedResponse<TwitterPerson> response = await resultSetIterator.ReadNextAsync();

                foreach (TwitterPerson twitterPerson in response)
                {
                    twitterPeopleList.Add(twitterPerson);
                }

                LogRequestCharge(response.RequestCharge);

                LogFullDiagnostics(response.Diagnostics);
            }

            if (twitterPeopleList.Count == 1)
            {
                return new ObjectResult(twitterPeopleList[0]);
            }

            // Let the caller know the resource for the ID could not be found.
            return NotFound($"Person {twitterId} not found.");
        }

        /// <summary>
        /// Creates specified twitter person.
        /// </summary>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="twitterPersonCreate">The twitter person to create</param>
        /// <returns>TwitterPerson</returns>
        [ProducesResponseType(typeof(TwitterPerson), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Route("/api/v1/{companyId}/TwitterPerson")]
        [HttpPost]
        public async Task<IActionResult> Post(string companyId, [FromBody]TwitterPersonCreate twitterPersonCreate)
        {
            ItemResponse<TwitterPerson> result;

            try
            {
                TwitterPerson twitterPerson = new(twitterPersonCreate);

                // Assign a unique id: REST Server assigns ID for POST                    
                twitterPerson.Id = Guid.NewGuid().ToString();

                // Ensuring that the companyId is correctly set.
                twitterPerson.CompanyId = companyId;

                result = await ContainerInstance.CreateItemAsync(twitterPerson, new PartitionKey(companyId));
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to create the Twitter person {message}", ex.Message);

                return StatusCode(StatusCodes.Status500InternalServerError, $"Exception {ex.Message}");
            }

            return CreatedAtRoute(GetTwitterPersonByIdRouteName, new { twitterId = result.Resource.Id, companyId = companyId }, result);
        }
    }


}
