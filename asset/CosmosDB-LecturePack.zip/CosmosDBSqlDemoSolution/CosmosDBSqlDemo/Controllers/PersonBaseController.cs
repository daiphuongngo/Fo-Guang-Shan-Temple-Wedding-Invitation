﻿// CSCI-E94 Fundamendals of cloud computing demo template with Microsoft Azure
// Joseph Ficara (c) 2015 - 2022
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using System.Runtime.CompilerServices;

namespace CosmosDBSqlDemo.Controllers
{
    /// <summary>
    /// Access to Person Collection in CosmosDB
    /// </summary>
    [Produces("application/json")]
    public class PersonBaseController<T> : Controller
    {
        private static readonly CosmosContainerCreationStrategy ContainerCreationStrategy = new();

        protected bool LogFullDiagnosticsEnabled;

        /// <summary>
        /// The _document client
        /// </summary>
        protected CosmosClient CosmosClientInstance;

        /// <summary>
        /// The _document database
        /// </summary>
        protected Database DatabaseInstance;

        /// <summary>
        /// The Container
        /// </summary>
        protected Container ContainerInstance;

        /// <summary>
        /// Logger instance
        /// </summary>
        protected ILogger Logger { get; private set; }

        /// <summary>
        /// The CosmosDB settings
        /// </summary>
        protected CosmosDBSettings CosmosDBSettings { get; private set; }


        /// <summary>
        /// Initializes a new instance of the <see cref="PersonController"/> class.
        /// </summary>
        /// <param name="cosmosDBSettings">The cosmos db settings</param>
        /// <param name="logger">The logger</param>
        public PersonBaseController(ILogger<T> logger,
                                    CosmosDBSettings cosmosDBSettings)
        {
            Logger = logger;
            CosmosDBSettings = cosmosDBSettings;

            // 1. Create the client used for interacting with the CosmosDB       
            CosmosClientInstance = new CosmosClient(CosmosDBSettings.EndpointUrl, cosmosDBSettings.CosmosDBKey);

            // 2. If the database does not exist, create it
            CreateDatabaseIfNotExist();

            // 3. If the collection does not exist, create it
            CreateContainerIfNotExist();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PersonBaseController{T}"/> class for tests that provide a container directly.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="cosmosDBSettings">The Cosmos DB settings.</param>
        /// <param name="containerInstance">The container instance.</param>
        protected PersonBaseController(ILogger logger,
                                       CosmosDBSettings cosmosDBSettings,
                                       Container containerInstance)
        {
            Logger = logger;
            CosmosDBSettings = cosmosDBSettings;
            ContainerInstance = containerInstance;
        }

        /// <summary>
        /// Creates the database if it does not exist.
        /// </summary>
        private void CreateDatabaseIfNotExist()
        {
            DatabaseInstance = CosmosClientInstance.CreateDatabaseIfNotExistsAsync(
                id: CosmosDBSettings.DatabaseName).GetAwaiter().GetResult();

            System.Diagnostics.Trace.TraceInformation($"Database CreateDatabaseIfNotExistsAsync databaseId: [{DatabaseInstance?.Id}]");
        }

        /// <summary>
        /// Creates the collection if it does not exist.
        /// </summary>
        private void CreateContainerIfNotExist()
        {
            ContainerProperties containerProperties = SetupIndexing($"/{CosmosDBSettings.PartitionKeyName}");

            ContainerInstance = ContainerCreationStrategy.CreateContainerIfNotExists(
                containerProperties: containerProperties,
                offerThroughput: CosmosDBSettings.OfferThroughput,
                logger: Logger,
                createWithoutThroughput: properties => DatabaseInstance.CreateContainerIfNotExistsAsync(
                    containerProperties: properties).GetAwaiter().GetResult(),
                createWithThroughput: (properties, throughput) => DatabaseInstance.CreateContainerIfNotExistsAsync(
                    containerProperties: properties,
                    throughput: throughput).GetAwaiter().GetResult());

            System.Diagnostics.Trace.TraceInformation($"Container CreateContainerIfNotExistsAsync collectionID: [{ContainerInstance?.Id}]");
        }

        /// <summary>
        /// Sets up the indexing options.
        /// </summary>
        protected virtual ContainerProperties SetupIndexing(string partitionPath)
        {
            ContainerProperties containerProperties = new ContainerProperties(

                id: CosmosDBSettings.CollectionName,
                partitionKeyPath: partitionPath
            );

            // Manditory path inclusion entry
            containerProperties.IndexingPolicy.IncludedPaths.Add(new IncludedPath() { Path = "/" });


            System.Diagnostics.Trace.TraceInformation("Default: IndexingPolicy.IndexingMode: {0}", containerProperties.IndexingPolicy.IndexingMode);
            System.Diagnostics.Trace.TraceInformation("Default: IndexingPolicy.Automatic: {0}", containerProperties.IndexingPolicy.Automatic);

            // DEMO
            //Set the indexing mode to Lazy (indexing occurs asynchronously with respect to Create, Update, Delete
            //containerProperties.IndexingPolicy.IndexingMode = IndexingMode.Lazy;

            // DEMO
            // Set the indexing policy to manual (indexing does not happen for items added to the collection automatically)
            //containerProperties.IndexingPolicy.Automatic = false;

            // DEMO Adding unique constraint on the facebookId
            //UniqueKeyPolicy uniqueKeyPolicy = new UniqueKeyPolicy();
            //UniqueKey uniqueKey = new UniqueKey();
            //uniqueKey.Paths.Add("/facebookId");
            //uniqueKeyPolicy.UniqueKeys.Add(uniqueKey);
            //containerProperties.UniqueKeyPolicy = uniqueKeyPolicy;

            // DEMO Excluding a path from indexing            
            //ExcludedPath excludedPath = new ExcludedPath();
            //excludedPath.Path = "/\"metadata\"/*";
            //containerProperties.IndexingPolicy.ExcludedPaths.Add(excludedPath);

            System.Diagnostics.Trace.TraceInformation("Current: IndexingPolicy.IndexingMode: {0}", containerProperties.IndexingPolicy.IndexingMode);
            System.Diagnostics.Trace.TraceInformation("Current: IndexingPolicy.Automatic: {0}", containerProperties.IndexingPolicy.Automatic);

            return containerProperties;
        }

        /// <summary>
        /// Logs the request charge
        /// </summary>
        /// <param name="requestCharge">The request charge</param>
        /// <param name="memberName">The method name of the caller where the request charge occured</param>
        protected void LogRequestCharge(double requestCharge, [CallerMemberName] string memberName = "")
        {
            Logger.LogWarning("Request Charge for {memberName}: {requestCharge}", memberName, requestCharge);
        }

        /// <summary>
        /// This logs the full diagnostics returned
        /// </summary>
        /// <param name="diagnostics">The full set of diagnosts returned</param>
        protected void LogFullDiagnostics(CosmosDiagnostics diagnostics)
        {
            if (diagnostics != null && LogFullDiagnosticsEnabled)
            {
                Logger.LogInformation(new String('+', 80));
                Logger.LogInformation("Diagnostics: {diagnostics}", diagnostics);
                Logger.LogInformation(new String('-', 80));
            }

        }
    }
}

