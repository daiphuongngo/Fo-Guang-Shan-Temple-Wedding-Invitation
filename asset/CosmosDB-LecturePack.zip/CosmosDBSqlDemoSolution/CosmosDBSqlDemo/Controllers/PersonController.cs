﻿// CSCI-E94 Fundamendals of cloud computing demo template with Microsoft Azure
// Joseph Ficara (c) 2018 - 2021
using System;
using System.Collections;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Threading.Tasks;
using CosmosDBSqlDemo.DataObjects;
using Microsoft.Azure.Cosmos;
using System.Runtime.CompilerServices;

namespace CosmosDBSqlDemo.Controllers
{
    /// <summary>
    /// Access to Person Collection in CosmosDB
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.Controller" />	
    [Produces("application/json")]
    public class PersonController : PersonBaseController<PersonController>
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="PersonController"/> class.
        /// </summary>
        public PersonController(ILogger<PersonController> logger,                                    
                                    CosmosDBSettings cosmosDBSettings) : base(logger, cosmosDBSettings)
        {
        }

        /// <summary>
        /// Gets all of the people in the people collection
        /// </summary>
        /// <param name="companyId">The company identifier.</param>
        /// <returns>The Persons in the Persons resource</returns>
        [ProducesResponseType(typeof(IEnumerable<object>), StatusCodes.Status200OK)]
        [Route("/api/v1/{companyId}/Person")]
        [HttpGet]
        public async Task<IActionResult> Get(string companyId)
        {
            ArrayList heterogeneousPeopleList = new ArrayList();

            // Define a SQL query to return all of the people
            QueryDefinition query = new QueryDefinition($"SELECT * FROM {CosmosDBSettings.CollectionName}");

            FeedIterator<Person> resultSetIterator = ContainerInstance.GetItemQueryIterator<Person>(query, requestOptions: new QueryRequestOptions() { PartitionKey = new PartitionKey(companyId) });

            // Note: This does not scale, the API should expose querying for additional
            // records and not attempt to get them all at once.
            while (resultSetIterator.HasMoreResults)
            {
                FeedResponse<Person> response = await resultSetIterator.ReadNextAsync();

                foreach (object item in response)
                {
                    heterogeneousPeopleList.Add(item);
                }

                LogRequestCharge(response.RequestCharge);

                LogFullDiagnostics(response.Diagnostics);
            }


            // Return the result set of people
            return new ObjectResult(heterogeneousPeopleList);

        }

        /// <summary>
        /// The name of the route for getting Person by id
        /// </summary>
        public const string GetPersonByIdRouteName = "GetPersonByIdRouteName";


        /// <summary>
        /// Gets the Person by id
        /// </summary>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="id">The identifier.</param>
        /// <returns>The Person associated with the id</returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Route("/api/v1/{companyId}/Person/{id}", Name = GetPersonByIdRouteName)]
        [HttpGet]
        public async Task<IActionResult> Get(string companyId, string id)
        {
            //Person resultPerson = await GetPersonByIdUsingSQL(companyId, id);

            // DEMO A faster approach
            Person resultPerson = await GetPersonById(companyId, id);

            if (resultPerson != null)
            {
                return new ObjectResult(resultPerson);
            }

            // Let the caller know the resource for the ID could not be found.
            return NotFound($"Person {id} not found.");
        }


        /// <summary>
        /// Gets the person by id for the company specified using direct lookup by id
        /// </summary>
        /// <param name="companyId">The company the person is in</param>
        /// <param name="id">The id of the person</param>
        /// <returns>The person or null if the person does not exist</returns>
        private async Task<Person> GetPersonById(string companyId, string id)
        {

            // Read using a "point read" which is faster
            // https://devblogs.microsoft.com/cosmosdb/point-reads-versus-queries/?msclkid=fcd42f81d0ac11eca60627f787e9e343

            ItemResponse<Person> response = await ContainerInstance.ReadItemAsync<Person>(partitionKey: new PartitionKey(companyId), id: id);

            LogRequestCharge(response.RequestCharge);

            LogFullDiagnostics(response.Diagnostics);

            return response.Resource;

        }

        /// <summary>
        /// Gets the person by id for the company specified
        /// </summary>
        /// <param name="companyId">The company the person is in</param>
        /// <param name="id">The id of the person</param>
        /// <returns>The person or null if the person does not exist</returns>
        private async Task<Person> GetPersonByIdUsingSQL(string companyId, string id)
        {
            List<Person> personList = new List<Person>();

            // Define a SQL query to a person
            QueryDefinition query = new QueryDefinition($"SELECT * FROM {CosmosDBSettings.CollectionName} p " +
                $"WHERE p.companyId = @CompanyId AND p.id = @Id")
                .WithParameter("@Id", id)
                .WithParameter("@CompanyId", companyId);

            FeedIterator<Person> resultSetIterator = ContainerInstance.GetItemQueryIterator<Person>(query, requestOptions: new QueryRequestOptions() { PartitionKey = new PartitionKey(companyId) });

            // Note: There should be only a single result
            while (resultSetIterator.HasMoreResults)
            {
                FeedResponse<Person> response = await resultSetIterator.ReadNextAsync();

                foreach (Person item in response)
                {
                    personList.Add(item);
                }

                LogRequestCharge(response.RequestCharge);

                LogFullDiagnostics(response.Diagnostics);
            }

            if (personList.Count > 0)
            {
                return personList[0];
            }

            return null;

        }

        /// <summary>
        /// Creates a Person
        /// </summary>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="personCreate">The person data to create</param>
        /// <returns>An action result describing the location and he entity created</returns>
        [ProducesResponseType(typeof(Person), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Route("/api/v1/{companyId}/Person")]
        [HttpPost]
        public async Task<IActionResult> Post(string companyId, [FromBody] PersonCreate personCreate)
        {
            ItemResponse<Person> result;

            try
            {
                Person person = new Person(personCreate)
                {
                    // Ensuring the correct company id is used
                    CompanyId = companyId
                };

                result = await ContainerInstance.CreateItemAsync(person, new PartitionKey(companyId));

                LogRequestCharge(result.RequestCharge);

            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceInformation("Failed to create the person {0}", ex.Message);

                return StatusCode(StatusCodes.Status500InternalServerError, $"Exception {ex.Message}");
            }

            return CreatedAtRoute(GetPersonByIdRouteName, new { id = result.Resource.Id, companyId = companyId }, result);

        }


        /// <summary>
        /// Updates the Person
        /// </summary>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="id">The identifier.</param>
        /// <param name="personUpdate">The Person to update or create.</param>
        /// <returns>Task&lt;IActionResult&gt;.</returns>
        [ProducesResponseType(typeof(string), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
        [Route("/api/v1/{companyId}/Person/{id}")]
        [HttpPut]
        public async Task<IActionResult> Put(string companyId, string id, [FromBody] PersonUpdate personUpdate)
        {
            try
            {
                Person person = new(personUpdate, id)
                {
                    CompanyId = companyId
                };
                var itemResponse = await ContainerInstance.UpsertItemAsync(person);

                LogRequestCharge(itemResponse.RequestCharge);

                if (itemResponse.StatusCode == System.Net.HttpStatusCode.Created)
                {
                    return CreatedAtRoute(GetPersonByIdRouteName, new { id = itemResponse.Resource.Id, companyId = companyId }, itemResponse.Resource);
                }
                else
                {
                    return NoContent();
                }
            }
            catch (CosmosException cex)
            {
                System.Diagnostics.Trace.TraceWarning("Failed to update/insert the person {0}", cex.Message);
                return StatusCode((int)cex.StatusCode, "Failed to update/insert the person");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceInformation("Failed to update the person {0}", ex.Message);

                return StatusCode(StatusCodes.Status500InternalServerError, $"Exception {ex.Message}");
            }

        }

        /// <summary>
        /// Deletes the specified Person associated with the id provided.
        /// </summary>
        /// <param name="companyId">The company identifier.</param>
        /// <param name="id">The identifier.</param>
        /// <returns>No content upon success, http StatusCodes.Status400BadRequest upon error</returns>
        [ProducesResponseType(typeof(string), StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Route("/api/v1/{companyId}/Person/{id}")]
        [HttpDelete]
        public async Task<IActionResult> Delete(string companyId, string id)
        {
            try
            {
                ItemResponse<Person> response = await ContainerInstance.DeleteItemAsync<Person>(partitionKey: new PartitionKey(companyId), id: id);

                LogRequestCharge(response.RequestCharge);


                return StatusCode((int)response.StatusCode);

            }
            catch (CosmosException cex)
            {
                System.Diagnostics.Trace.TraceWarning("Failed to delete the person {0}", cex.Message);
                return StatusCode((int)cex.StatusCode, "Failed to delete the person");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError("Failed to delete the person {0}", ex.Message);

                return StatusCode(StatusCodes.Status500InternalServerError, $"Exception {ex.Message}");
            }
        }
    }
}
