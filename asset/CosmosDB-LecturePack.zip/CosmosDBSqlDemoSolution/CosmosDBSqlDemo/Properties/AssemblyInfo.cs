using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("CosmosDBSqlDemo.Tests")]
