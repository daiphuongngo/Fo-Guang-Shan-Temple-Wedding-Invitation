#nullable enable
using System.Net;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;

namespace CosmosDBSqlDemo
{
    /// <summary>
    /// Creates Cosmos DB containers while handling the serverless and provisioned account behaviors.
    /// </summary>
    public class CosmosContainerCreationStrategy
    {
        /// <summary>
        /// Creates the container if it does not exist by preferring the serverless-compatible overload first.
        /// </summary>
        /// <param name="containerProperties">The container properties.</param>
        /// <param name="offerThroughput">The provisioned throughput to use when it is required.</param>
        /// <param name="logger">The logger used to record strategy decisions and retries.</param>
        /// <param name="createWithoutThroughput">Delegate that creates the container without throughput.</param>
        /// <param name="createWithThroughput">Delegate that creates the container with provisioned throughput.</param>
        /// <returns>The created or existing container.</returns>
        public Container CreateContainerIfNotExists(
            ContainerProperties containerProperties,
            int offerThroughput,
            ILogger logger,
            Func<ContainerProperties, Container> createWithoutThroughput,
            Func<ContainerProperties, int, Container> createWithThroughput)
        {
            ArgumentNullException.ThrowIfNull(containerProperties);
            ArgumentNullException.ThrowIfNull(logger);
            ArgumentNullException.ThrowIfNull(createWithoutThroughput);
            ArgumentNullException.ThrowIfNull(createWithThroughput);

            logger.LogInformation(
                "Attempting container creation without throughput for container {containerId}.",
                containerProperties.Id);

            if (TryCreateContainerForServerlessAccount(
                containerProperties,
                logger,
                createWithoutThroughput,
                out Container container))
            {
                logger.LogInformation(
                    "Using no-throughput container creation strategy for container {containerId}.",
                    containerProperties.Id);
                return container;
            }

            logger.LogInformation(
                "Attempting container creation with throughput {throughput} for container {containerId}.",
                offerThroughput,
                containerProperties.Id);

            Container throughputContainer = createWithThroughput(containerProperties, offerThroughput);

            logger.LogInformation(
                "Using provisioned-throughput container creation strategy for container {containerId}.",
                containerProperties.Id);

            return throughputContainer;
        }

        /// <summary>
        /// Determines whether the container-creation failure indicates that provisioned throughput is required.
        /// </summary>
        /// <param name="exception">The Cosmos exception raised by the no-throughput create attempt.</param>
        /// <returns><c>true</c> when the account requires provisioned throughput; otherwise, <c>false</c>.</returns>
        public bool IsProvisionedThroughputRequired(CosmosException exception)
        {
            ArgumentNullException.ThrowIfNull(exception);

            return exception.StatusCode == HttpStatusCode.BadRequest
                && exception.Message.Contains("throughput", StringComparison.OrdinalIgnoreCase)
                && (exception.Message.Contains("required", StringComparison.OrdinalIgnoreCase)
                    || exception.Message.Contains("offer", StringComparison.OrdinalIgnoreCase));
        }

        private bool TryCreateContainerForServerlessAccount(
            ContainerProperties containerProperties,
            ILogger logger,
            Func<ContainerProperties, Container> createWithoutThroughput,
            out Container container)
        {
            try
            {
                container = createWithoutThroughput(containerProperties);
                return true;
            }
            catch (CosmosException exception) when (IsProvisionedThroughputRequired(exception))
            {
                logger.LogInformation(
                    "No-throughput container creation is not supported for container {containerId}; falling back to provisioned throughput.",
                    containerProperties.Id);
                container = null!;
                return false;
            }
        }
    }
}
