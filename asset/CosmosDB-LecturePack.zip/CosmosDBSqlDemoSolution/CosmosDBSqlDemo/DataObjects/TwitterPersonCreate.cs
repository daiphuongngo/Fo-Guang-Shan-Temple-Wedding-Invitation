﻿#nullable disable
namespace CosmosDBSqlDemo.DataObjects
{
    /// <summary>
    /// Defines a twitter person
    /// </summary>
    public class TwitterPersonCreate : PersonCreate
    {
        /// <summary>
        /// The person's twitter identifier.
        /// </summary>
        /// <value>The twitter identifier.</value>
        public string TwitterId { get; set; }

        /// <summary>
        /// The number of tweets made by the person.
        /// </summary>
        /// <value>The number of tweets.</value>
        public int NumberOfTweets { get; set; }
    }
}
