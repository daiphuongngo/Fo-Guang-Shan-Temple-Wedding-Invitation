namespace CosmosDBSqlDemo.DataObjects
{
    /// <summary>
    /// Represents a company and the distinct person types associated with it.
    /// </summary>
    public class Company
    {
        /// <summary>
        /// Gets or sets the company identifier.
        /// </summary>
        public string CompanyId { get; set; }

        /// <summary>
        /// Gets or sets the distinct person types for the company.
        /// </summary>
        public List<string> PersonTypes { get; set; } = new();
    }
}
