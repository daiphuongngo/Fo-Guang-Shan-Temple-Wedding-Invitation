﻿#nullable disable
namespace CosmosDBSqlDemo.DataObjects
{
    /// <summary>
    /// /// Defines a twitter person
    /// </summary>
    public class FacebookPersonCreate : PersonCreate
    {
        /// <summary>
        /// The facebook identifier of the person.
        /// </summary>
        /// <value>The facebook identifier.</value>
        public string FacebookId { get; set; }

        /// <summary>
        /// The number of facebook posts made by the person
        /// </summary>
        /// <value>The facebook posts.</value>
        public int FacebookPosts { get; set; }

    }
}
