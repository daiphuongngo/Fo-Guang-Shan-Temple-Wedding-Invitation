﻿#nullable disable
using Newtonsoft.Json;

namespace CosmosDBSqlDemo.DataObjects
{
    /// <summary>
    /// Defines a twitter person
    /// </summary>
    public class Person
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        /// <remarks>
        /// The Id property needs to be lower case for Cosmos DB to recognize it        
        /// </remarks>
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets the company identifier.
        /// </summary>
        /// <value>The company identifier.</value>
        [JsonProperty("companyId")]
        public string CompanyId { get; set; }

        /// <summary>
        /// The persons name
        /// </summary>
        /// <value>The name.</value>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// The persons age
        /// </summary>
        /// <value>The age.</value>
        [JsonProperty("age")]
        public int Age { get; set; }

        /// <summary>
        /// Set automatically, and defines the type of person
        /// </summary>
        /// <value>The type of the person.</value>
        [JsonProperty("personType")]
        public string PersonType { get; protected set; }

        /// <summary>
        /// Metadata about the person
        /// </summary>
        /// <value>The metadata.</value> 
        [JsonProperty("metadata")]
        public string Metadata { get; set; }

        /// <summary>
        /// The date and time the person joined
        /// </summary>
        /// <value>The member since.</value>
        [JsonProperty("memberSince")]
        public DateTime MemberSince { get; set; }

        /// <summary>
        /// Gets the member since using the Ticks value
        /// </summary>
        /// <value>The member since timestamp.</value>
        /// <remarks>To convert back to a date time use DateTime.FromBinary</remarks>
        [JsonProperty("memberSinceTimeStamp")]
        public long MemberSinceTimeStamp
        {
            get { return MemberSince.Ticks; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Person"/> class.
        /// </summary>
        [Newtonsoft.Json.JsonConstructor]
        public Person(string providedId = null)
        {
            PersonType = typeof(Person).Name;

            if (string.IsNullOrWhiteSpace(providedId))
            {
                // Generate a unique id for the item "document" this is RESTfull because we are using POST
                Id = Guid.NewGuid().ToString();
            }
            else
            {
                Id = providedId;
            }
        }

        public Person(PersonUpdate personUpdate, string Id) : this(Id)
        {
            this.MemberSince = personUpdate.MemberSince;
            this.Metadata = personUpdate.Metadata;
            this.Name = personUpdate.Name;
            this.Age = personUpdate.Age;
        }

        public Person(PersonCreate personCreate) : this()
        {
            this.MemberSince = personCreate.MemberSince;
            this.Metadata = personCreate.Metadata;
            this.Name = personCreate.Name;
            this.Age = personCreate.Age;
        }
    }
    
}
