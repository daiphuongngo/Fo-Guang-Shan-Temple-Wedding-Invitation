﻿#nullable disable
using Newtonsoft.Json;

namespace CosmosDBSqlDemo.DataObjects
{
    /// <summary>
    /// /// Defines a twitter person
    /// </summary>
    public class FacebookPerson : Person
    {
        /// <summary>
        /// The facebook identifier of the person.
        /// </summary>
        /// <value>The facebook identifier.</value>  
        [JsonProperty("facebookId")]
        public string FacebookId { get; set; }

        /// <summary>
        /// The number of facebook posts made by the person
        /// </summary>
        /// <value>The facebook posts.</value>
        [JsonProperty("facebookPosts")]
        public int FacebookPosts { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="FacebookPerson"/> class.
        /// </summary>
        public FacebookPerson()
        {
            PersonType = typeof(FacebookPerson).Name;
        }

        /// <summary>
        /// Constructs a FacebookPerson from a FacebookPersonCreate
        /// </summary>
        /// <param name="facebookPersonCreate">The source facebok person to create from</param>
        public FacebookPerson(FacebookPersonCreate facebookPersonCreate) : base(facebookPersonCreate)
        {
            this.FacebookId = facebookPersonCreate.FacebookId;
            this.FacebookPosts = facebookPersonCreate.FacebookPosts;
            this.PersonType = typeof(FacebookPerson).Name;
        }
    }
}
