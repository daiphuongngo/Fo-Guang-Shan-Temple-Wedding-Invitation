﻿#nullable disable
using Newtonsoft.Json;

namespace CosmosDBSqlDemo.DataObjects
{
    /// <summary>
    /// Defines a twitter person
    /// </summary>
    public class TwitterPerson : Person
    {
        /// <summary>
        /// The person's twitter identifier.
        /// </summary>
        /// <value>The twitter identifier.</value>
        [JsonProperty("twitterId")]
        public string TwitterId { get; set; }

        /// <summary>
        /// The number of tweets made by the person.
        /// </summary>
        /// <value>The number of tweets.</value>
        [JsonProperty("numberOfTweets")]
        public int NumberOfTweets { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="FacebookPerson"/> class.
        /// </summary>
        public TwitterPerson()
        {
            PersonType = typeof(TwitterPerson).Name;
        }


        /// <summary>
        /// Constructs a TwitterPerson from a TwitterPersonCreate
        /// </summary>
        /// <param name="twitterPersonCreate">The source twitter person to create from</param>
        public TwitterPerson(TwitterPersonCreate twitterPersonCreate) : base(twitterPersonCreate)
        {
            this.NumberOfTweets = twitterPersonCreate.NumberOfTweets;
            this.TwitterId = twitterPersonCreate.TwitterId;   
            PersonType = typeof(TwitterPerson).Name;
        }
    }
}
