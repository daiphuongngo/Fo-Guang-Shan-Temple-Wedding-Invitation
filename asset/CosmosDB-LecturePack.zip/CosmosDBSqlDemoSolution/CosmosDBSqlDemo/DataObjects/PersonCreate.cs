﻿#nullable disable
namespace CosmosDBSqlDemo.DataObjects
{
    /// <summary>
    /// Defines a twitter person
    /// </summary>
    public class PersonCreate
    {
        /// <summary>
        /// The persons name
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; }

        /// <summary>
        /// The persons age
        /// </summary>
        /// <value>The age.</value>
        public int Age { get; set; }

        /// <summary>
        /// Set automatically, and defines the type of person
        /// </summary>
        /// <value>The type of the person.</value>
        public string PersonType { get; protected set; }

        /// <summary>
        /// Metadata about the person
        /// </summary>
        /// <value>The metadata.</value> 
        public string Metadata { get; set; }

        /// <summary>
        /// The date and time the person joined
        /// </summary>
        /// <value>The member since.</value>
        public DateTime MemberSince { get; set; }

        /// <summary>
        /// Gets the member since using the Ticks value
        /// </summary>
        /// <value>The member since timestamp.</value>
        /// <remarks>To convert back to a date time use DateTime.FromBinary</remarks>
        public long MemberSinceTimeStamp
        {
            get { return MemberSince.Ticks; }
        }

    }
    
}
