﻿#nullable disable
// CSCI-E94 Fundamendals of cloud computing demo template with Microsoft Azure
// Joseph Ficara (c) 2013 - 2022
namespace CosmosDBSqlDemo
{
    /// <summary>
    /// Defines the CosmosDB settings
    /// </summary>
    public class CosmosDBSettings
    {
        /// <summary>
        /// Gets or sets the endpoint URL
        /// </summary>
        /// <value>
        /// The endpoint URL
        /// </value>
        public string EndpointUrl { get; set; }

        /// <summary>
        /// Gets or sets the name of the database.
        /// </summary>
        /// <value>The name of the database.</value>
        public string DatabaseName { get; set; } = "PeopleDb";

        /// <summary>
        /// Gets or sets the name of the collection.
        /// </summary>
        /// <value>The name of the collection.</value>
        public string CollectionName { get; set; } = "PeopleCollection";

        /// <summary>
        /// Gets or sets the name of the partition key.
        /// </summary>
        /// <value>The name of the partition key.</value>
        public string PartitionKeyName { get; set; } = "companyId";

        /// <summary>
        /// Gets or sets the offer throughput.
        /// </summary>
        /// <value>The offer throughput.</value>
        /// <remarks>This is the number of RUs the collection will support when creating it.</remarks>
        public int OfferThroughput { get; set; } = 400;

        /// <summary>
        /// The Cosmos DB API key
        /// </summary>
        public string CosmosDBKey { get; set; }
    }
}
